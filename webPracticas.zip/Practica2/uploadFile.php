<?php
require_once "utilities.php";

use Phppot\Member;

if (!empty($_SESSION["rol"])) {
   $rol = $_SESSION["rol"];
   if ($rol == 1) {
   } else {
      $url = "./index.php";
      header("Location: $url");
   }
} else {
   $url = "./index.php";
   header("Location: $url");
}


menu("Subir foto", "register.css"); //llama a la funcion que esta en la carpeta utilities.php
menuUser(); //Llama a la funcion que esta en utitlities.php donde se ve el menu del Administrador
$userId = $codeBox =  ""; //Declaro

require_once __DIR__ . '/lib/Member.php'; //Llama al archivo Member.php
$users = new Member();
$usersArray = $users->getAllUsers();//Llama a la función que esta en Member.php


if (!empty($_POST["upload-btn"])) { //El boton con name=upload-btn, si esta presionado
   $userId = testInput($_POST["id-user"]);
   $codeBox = testInput($_POST["codigo-caja"]);
   require_once __DIR__ . '/lib/Member.php';
   $member = new Member();
   $fileResult = $member->uploadFile($codeBox, $userId); //Se envia a la funcion uploadFile de Member.php con dos parametros
}
?>
<div class="container col-10 col-md-8 col-lg-6" id="paddingMainDiv">
   <?php
   if (empty($usersArray)) {
   ?>
      <div class="alert alert-success">Error en la conexión sql</div>
   <?php
   }
   ?>
   <div class="col-12 col-md-12 text-center mt-5 blue-color">
      <h1>Subir una caja</h1>
   </div>
   <br>
   <div id="datosUsuario" class="table-responsive">
      <!-- Formulario para subir c -->
      <form name="upload" action="" method="post" enctype="multipart/form-data" class="formulario2">
      <!-- Select para seleccionar un usuario de la base de datos -->
         <div class="input-group form-group mt-3">
            <select name="id-user" class="form-control">
               <option value="">Seleccione un usuario</option>
               <?php
               for ($i = 0; $i < count($usersArray); $i++) {
                  echo '<option value="' . $usersArray[$i]["id"] . '">' . $usersArray[$i]["id"] . ' - ' . $usersArray[$i]["email"] . '</option>'; //close your tags!!
               }
               ?>
            </select>
         </div>
      <!-- Input para introducir el codigo de caja -->
         <div class="input-group form-group mt-3">
            <input type="text" class="form-control p-3" placeholder="codigo-caja *" name="codigo-caja" value="<?php echo $codeBox ?>">
         </div>
      <!-- Input para seleccionar archivo -->
         <div class="input-group form-group mt-3">
            <input type="file" name="file">
         </div>
      <!-- Boton de Subir caja -->
         <div class="text-center">
            <input type="submit" value="Crear caja" class="btn mt-3 w-100 p-2" name="upload-btn" id="blue-box">
         </div>
      </form> <
      <?php if (!empty($fileResult)) { ?>
         <br>
         <input type="button" value="<?php echo $fileResult; ?>" class="btn mt-3 w-100 p-1 bg-warning text-dark">

         <div class="bg-warning text-danger" <?php echo $fileResult; ?>></div>
      <?php } ?>

   </div>
</div>

</body>
<script>
   //JS para recargar la pagina
   $(document).ready(function() {
      $(".jm-loadingpage").fadeOut("slow");
   });
</script>
</body>
<?php
footer();
?>