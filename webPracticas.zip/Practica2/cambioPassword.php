<?php
//Call the file, llama al archivo
// error_reporting(0); //Desactiva las notificaciones de PHP
require_once "utilities.php";

use Phppot\Member;

menu("Cambio de contraseña", "register.css"); //llama al menu que esta en el archivo utilities.php
menuNoUser(); //Menu no Usuario

//Configurando variables que usaremos.
$email = $errorEmail =  "";
$flag = false;

?>
<?php
if (isset($_POST["submitEmail"])) { //Si existe la variable (si presionamos el button con name="submit")
    //Configuración de las variables ingresadas.
    $email = testInput($_POST["email"]);

    //**********************VALIDAMOS LAS ENTRADAS REALIZADAS POR EL USUARIO******************************* */

    /**************************************VALIDACIÓN DEL EMAIL************************************ */
    $recrex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';
    if (empty($email)) {
        $flag = true;
        $errorEmail = "Debes rellenar el email";
    } else if (!preg_match($recrex, $email)) {
        $flag = true;
        $errorEmail = "Error de correo electronico";
    }

    //Verificamos si los datos introducidos en el formulario son correctos (con variable boolean)
    //Si son correctos, se enviara un correo electronico o se mostrara un mensaje informando al usuario.
    if ($flag != false) {
        //Parte del error
    } else {
        //En caso de que no haya error
        require_once __DIR__ . '/lib/Member.php';
        $member = new Member();
        $statusMSG = $member->restorePassword($email);
    }
} //fin del boton submit
?>  

    <div class="d-flex flex-column min-vh-100 justify-content-center align-items-center" id="register-box">
        <?php
        if (!empty($statusMSG)) {
        ?>
            <div class="alert alert-<?php echo $statusMSG[0] ?>"><?php echo $statusMSG[1]; ?></div>
        <?php
            $statusMSG = null;
        }
        ?>
        <img src="images/logo_Guardamelo.png" alt="Logo de guardamelo">
        <div class="row">
            <div class="container col-11 col-sm-8 col-md-10 col-lg-10 formulario">
                <form class="form-horizontal" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <h1 class="text-center m-5">Cambio de contraseña</h1>
                    <p class="text-white ml-4">* Campos obligatorios</p>
                    <!-- Correo Electronico -->
                    <div class="container mb-4">
                        <div>
                            <input type="text" class="form-control" name="email" placeholder="E-mail *" value="<?php echo $email ?>">
                            <span class="text-danger"> <?php echo $errorEmail ?></span>
                        </div>
                    </div>
                    <!-- Botón de registrar -->
                    <div class="container mb-5 mt-3 registrar">
                        <input type="submit" name="submitEmail" value="Comprobar" class="btn btn-lg btn-block">
                    </div>
                </form>
                <!--fin del formulario de registro -->
            </div>
        </div>
    </div>

    <!-- JAVASCRIPT para mostrar el modal -->
<script>
    $(document).ready(function() {
        $(".jm-loadingpage").fadeOut("slow");
    });
</script>
</body>
<!-- Llama a la funcion footer que esta en el archivo utilities.php -->
<?php
footer();
?>
</html>