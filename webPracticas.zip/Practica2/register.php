
<?php
//Call the file
error_reporting(0);//Desactiva las notificaciones de PHP
require_once "utilities.php";

use Phppot\Member;

menu("Registro", "register.css"); //llama a la funcion menu del archivo utilities.php
menuNoUser(); //Menu none user del archivo utilities.php

//Creamos las variables que utilizamos en el formulario
$nombre = $apellido = $email = $telefono = $direccion = $password = $password2 = $politica =  $condicionesUso = "";
$errorNombre = $errorApellido = $errorEmail = $errorTelefono = $errorDireccion = $errorPassword = $errorEmail2 = "";
$errorPassword2 = $errorPolitica = $errorCondiciones = "";
$flag = false;

?>
<?php

if (isset($_POST["submit"])) { //Si existe la variable (si presionamos el button con name="submit")
    //Setting up the inputed variables.
    $nombre = testInput($_POST["nombre"]);
    $apellido = testInput($_POST["apellidos"]);
    $email = testInput($_POST["email"]);
    $telefono = testInput($_POST["telefono"]);
    //$direccion = testInput($_POST["direccion"]);
    $password = testInput($_POST["password"]);
    $password2 = testInput($_POST["password2"]);
    $politica = testInput($_POST["politica"]);
    $condicionesUso = testInput($_POST["condiciones"]);

    //**********************WE VALIDATE THE DATA ENTERED BY THE USER******************************* */

    /**************************************VALIDACIÓN DEL NOMBRE *************************************/
    if (empty($nombre)) {
        $flag = true;
        $errorNombre = "El nombre no debe estar vacío";
    } else if (preg_match("/[()\d]/", $nombre)) {
        $flag = true;
        $errorNombre = "El nombre no puede contener números";
    }
    /*************************************VALIDACIÓN DEL APELLIDO********************************** */
    if (empty($apellido)) {
        $flag = true;
        $errorApellido = "El apellido no debe estar vacío";
    } else if (preg_match("/[()\d]/", $apellido)) {
        $flag = true;
        $errorApellido = "El apellido no puede contener números";
    }
    /**************************************VALIDACIÓN DEL EMAIL************************************ */
    $recrex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';
    if (empty($email)) {
        $flag = true;
        $errorEmail = "Debes rellenar el email";
    } else if (!preg_match($recrex, $email)) {
        $flag = true;
        $errorEmail = "Error de correo electronico";
    }
    /***********************************VALIDACIÓN DEL TELEFONO*************************************** */
    if (empty($telefono)) {
        $flag = true;
        $errorTelefono = "El número de móvil no puede estar vacío";
    } else if (!preg_match("/^[0-9]{9,9}$/", $telefono)) {
        $flag = true;
        $errorTelefono = "El número de móvil debe tener 9 dígitos";
    }
    /***********************************VALIDACIÓN DE LA DIRECCION************************************* */
    // if (empty($direccion)) {
    //     $flag = true;
    //     $errorDireccion = "La dirección no debe estar vacía";
    // } else {
    // }
    /***********************************VALIDACIÓN DE LA CONTRASEÑA************************************** */
    if (empty($password)) {
        $flag = true;
        $errorPassword = "La contraseña no debe estar vacía";
    } else {
    }
    /**********************************VALIDACIÓN DE REPETIR CONTRASEÑA********************************** */
    if ($password != $password2) {
        $flag = true;
        $errorPassword2 = "Las contraseñas deben ser iguales";
    }
    /*********************************VALIDACIÓN DE POLITICA DE PRIVACIDAD***************************** */
    if (empty($politica)) {
        $errorPolitica = "Debes aceptar la politica de privacidad";
    } else {
        
    }
    /*********************************VALIDACIÓN CONDICIONES DE USO************************************ */
    if (empty($condicionesUso)) {
        $errorCondiciones = "Acepta las condiciones Generales de Uso";
    } else {

    }

    //Verificamos si los datos introducidos en el formulario son correctos (con variable boolean)
    //Si son correctos, puedes iniciar sesión
    if ($flag != false) { //($flag == true)
        //Parte del error
    } else {
        //En caso de que no haya error ($flag == false)
        require_once __DIR__ . '/lib/Member.php';
        $member = new Member();
        $errorEmail2 = $member->registerMember($nombre, $apellido, $email, $direccion, $password, $telefono);
    }
} //fin del boton submit

?>
<!-- ****************************FORMULARIO DE REGISTRO******************************************** -->
<div class="d-flex flex-column min-vh-100 justify-content-center align-items-center" id="register-box">
    <img src="images/logo_Guardamelo.png" alt="Logo de guardamelo">
    <div class="row">
        <div class="container col-11 col-sm-8 col-md-10 col-lg-10 formulario">
            <form class="form-horizontal" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <h1 class="text-center m-5">Formulario de registro</h1>
                <p class="text-white ml-4">* Campos obligatorios</p>
                <!-- Nombre -->
                <div class="container mb-4">
                    <div>
                        <input type="text" class="form-control" name="nombre" placeholder="Nombre *" value="<?php echo $nombre ?>">
                        <span class="text-danger"><?php echo $errorNombre ?></span>
                    </div>
                </div>
                <!-- Apellido -->
                <div class="container mb-4">
                    <div>
                        <input type="text" class="form-control" name="apellidos" placeholder="Apellidos *" value="<?php echo $apellido ?>">
                        <span class="text-danger"> <?php echo $errorApellido ?></span>
                    </div>
                </div>
                <!-- Correo Electronico -->
                <div class="container mb-4">
                    <div>
                        <input type="text" class="form-control" name="email" placeholder="E-mail *" value="<?php echo $email ?>">
                        <span class="text-danger"> <?php echo $errorEmail ?></span>
                        <span class="text-danger"> <?php echo $errorEmail2 ?></span>
                    </div>
                </div>
                <!-- Telefono -->
                <div class="container">
                    <div>
                        <input type="text" class="form-control" name="telefono" placeholder="Teléfono *" value="<?php echo $telefono ?>">
                        <span class="text-danger"> <?php echo $errorTelefono ?></span>
                    </div>
                </div>
                <!-- password -->
                <div class="container">
                    <div class="campo">
                        <label for="password"></label>
                        <input type="password" id="password" class="form-control mb-2" name="password" placeholder="Contraseña *" value="<?php echo $password ?>">
                        <button type="button" class="btn btn-primary buttonPassword">Mostrar</button>
                        <span class="text-danger"> <?php echo $errorPassword ?></span>
                    </div>
                </div>
                <!-- repetir password -->
                <div class="container mb-3">
                    <div class="campo2">
                        <label for="password2"></label>
                        <input type="password" id="password2" class="form-control mb-2" name="password2" placeholder="Repite tu contraseña  *" value="<?php echo $password2 ?>">
                        <button type="button" class="btn btn-primary buttonPassword">Mostrar</button>
                        <span class="text-danger"> <?php echo $errorPassword2 ?></span>
                    </div>
                </div>
                <!-- Politica de privacidad -->
                <div class="ml-3">
                    <div>
                        <label class="privacidad">
                            <input type="checkbox" name="politica"> He leído y acepto la <u><a type="button" data-toggle="modal" data-target="#exampleModalCenter" class="hover">
                                Politica de Privacidad</a></u>
                        </label><br>
                        <span class="text-danger"> <?php echo $errorPolitica ?></span>
                    </div>
                </div>
                <!-- Aceptar condiciones generales de uso -->
                <div class="ml-3">
                    <div>
                        <label class="privacidad">
                            <input type="checkbox" name="condiciones"> Acepto las <u><a type="button" data-toggle="modal" data-target="#condicionesGenerales" class="hover">
                                Condiciones de Uso</a></u>
                        </label><br>
                        <span class="text-danger"> <?php echo $errorCondiciones ?></span>
                    </div>
                </div>
                <!-- Botón de registrar -->
                <div class="container mb-5 mt-3 registrar">
                    <input type="submit" name="submit" value="Registrar" class="btn btn-lg btn-block">
                </div>
            </form>  <!--fin del formulario de registro -->
            <!-- Modal que muestra la politica de privacidad-->
            <div id="politicaPrivacidad">
                <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class=" row modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content col-11 col-md-12 col-lg-12 mt-5">
                            <div class="modal-header">
                                <h5 class="text-dark">Politica de privacidad</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="text-danger"> <!--Texto que el usuario lee sobre politica de privacidad -->
                                <p id="policy" class="p-3">Lorem2, ipsum dolor sit amet consectetur adipisicing elit.
                                    Amet et cupiditate laudantium. Ut distinctio veniam, provident, pariatur cum
                                    libero quasi reiciendis debitis, rerum delectus voluptatibus alias rem nostrum
                                    repellendus? Autem dolore ullam voluptates ducimus voluptas sapiente quasi aut
                                    maxime molestiae totam quod iusto nemo dolorem exercitationem suscipit,
                                    voluptate adipisci eligendi et sequi quos quae blanditiis! Ratione, unde sit
                                    doloremque id dicta odio expedita voluptatum inventore eum in molestiae nulla
                                    consectetur accusamus. Aliquam, laudantium, voluptates ullam itaque adipisci
                                    incidunt accusamus labore molestias, iure debitis quos nihil beatae nam error
                                    soluta nesciunt at sed minus ipsum veritatis cumque commodi dolorum amet quae.
                                </p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!--fin del modal de politica de privacidad -->
            <!-- Modal para Aceptar las condiciones generales de uso -->
            <div>
                <div class="modal fade" id="condicionesGenerales" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="row modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content col-11 col-md-12 col-lg-12 mt-5">
                            <div class="modal-header">
                                <h5 class="text-dark">Condiciones Generales de Uso</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="text-danger"> <!--Texto que el usuario lee para Aceptar las condiciones generales de uso -->
                                <p id="policy" class="p-3 text-primary">Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                                    Amet et cupiditate laudantium. Ut distinctio veniam, provident, pariatur cum
                                    libero quasi reiciendis debitis, rerum delectus voluptatibus alias rem nostrum
                                    repellendus? Autem dolore ullam voluptates ducimus voluptas sapiente quasi aut
                                    maxime molestiae totam quod iusto nemo dolorem exercitationem suscipit,
                                    voluptate adipisci eligendi et sequi quos quae blanditiis! Ratione, unde sit
                                    doloremque id dicta odio expedita voluptatum inventore eum in molestiae nulla
                                    consectetur accusamus. Aliquam, laudantium, voluptates ullam itaque adipisci
                                    incidunt accusamus labore molestias, iure debitis quos nihil beatae nam error
                                    soluta nesciunt at sed minus ipsum veritatis cumque commodi dolorum amet quae.
                                    incidunt accusamus labore molestias, iure debitis quos nihil beatae nam error  
                                </p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-dark" data-dismiss="modal">Cerrar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!--fin de modal de condiciones generales de uso -->
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $(".jm-loadingpage").fadeOut("slow");
    });
    //Script para mostrar / ocultar los botones para ver la contraseña introducida por el usuario
    document.querySelector('.campo button').addEventListener('click', e => {
        const passwordInput = document.querySelector('#password');
        if (e.target.classList.contains('show')) {
            e.target.classList.remove('show');
            e.target.textContent = 'Ocultar';
            passwordInput.type = 'text';
        } else {
            e.target.classList.add('show');
            e.target.textContent = 'Mostrar';
            passwordInput.type = 'password';
        }
    });
    //Script para mostrar / ocultar los botones para ver la contraseña introducida por el usuario
    document.querySelector('.campo2 button').addEventListener('click', e => {
        const passwordInput2 = document.querySelector('#password2');
        if (e.target.classList.contains('show')) {
            e.target.classList.remove('show');
            e.target.textContent = 'Ocultar';
            passwordInput2.type = 'text';
        } else {
            e.target.classList.add('show');
            e.target.textContent = 'Mostrar';
            passwordInput2.type = 'password';
        }
    });
</script>
</body>
<?php
footer();
?>

</html>