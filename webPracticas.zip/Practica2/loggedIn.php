<?php
require_once "utilities.php"; //Call al menu de oho
menu("Perfil", "loggedIn.css"); //llama al menu que esta en el archivo utilities.php
//Comprobamos si esta escrito el correo electronico para poder ingresar a tus datos
//ya sea como administrador o como usuario
if (!empty($_SESSION["email"])) {
	$email = $_SESSION["email"];
	$apellidos = $_SESSION["apellidos"];
	$telefono = $_SESSION["telefono"];
	//$direccion = $_SESSION["direccion"];
	$nombre = $_SESSION["nombre"];
	$rol = $_SESSION["rol"];
	if (!empty($_SESSION["caja"])) {
		$caja =  $_SESSION["caja"];
	}
} else { //Si no tiene el mail lregistrado en la base de datos te envia al index para registrar o loguear
	session_unset(); //libera las variables de sesion registradas
	$url = "./index.php";
	header("Location: $url");
}

menuUser(); //llama al menú que esta en el archivo utilities.php

session_write_close(); //Finaliza la sesión actual y almacena la información de la sesión.
?>
<!-- Formulario que muestra los datos del usuario -->
<div class="d-flex flex-column min-vh-100 justify-content-center align-items-center">
	<div class="container-fluid table-responsive">
		<div class="contact-area">
			<div class="contact">
				<div class="col-12 col-md-12 text-center mt-5 blue-color">
					<h2 class="welcome">¡Bienvenido <?php echo $nombre; ?>! <br> Aquí tienes tus datos.</h2>
				</div>
				<main>
					<section>
						<div class="content">
							<?php //TODO implementacion de imagen dinamica para el usuario. 
							?>
							<img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/256492/_mLIxaKY_400x400.jpg" alt="Profile Image">
							<aside>
								<h1><?php echo $nombre . " " . $apellidos ?> </h1> <!--printa nom y apelli -->
								<p>Teléfono: <?php echo $telefono ?></p><!--printa telefono -->
								<p>E-mail: <?php echo $email ?></p><!--printa email -->
							</aside>
						</div>
					</section>
				</main>
			</div>
		</div>
	</div>
</div> <!-- Fin del formulario que muestra los datos del usuario -->
<script>
	//Para recargar la pagina
	$(document).ready(function() {
		$(".jm-loadingpage").fadeOut("slow");
	});
</script>
</body>
<?php
footer();

?>

</html>