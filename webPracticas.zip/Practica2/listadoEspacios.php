<?php
require_once "utilities.php"; //Llama a este archivo php
require_once __DIR__ . '/lib/Member.php'; //llama a este archivo php

use Phppot\Member; //para poder utilizar el archivo Member.php

//Checkinh up the variables that are necessary for enter to this file
//Verifica las variables que son necesarias para ingresar a este archivo
if (!empty($_SESSION["email"])) { //Verifica que este colocado el mail en el input
    //Entra con rol administrador
    $nombre = $_SESSION["nombre"]; //guarda la variable para comprobar si entra como admin o usuario
    if ($_SESSION["rol"] == 1) {  //con rol administrador
        $users = new Member();
        $usersArray = $users->getAllUsers();
    }
} else { //si no es administrador destruye la sesion y lo envia al archivo index.php para loguearse
    session_unset();
    $url = "./index.php";
    header("Location: $url");
}
//Calling the necessary menus. 
//Llama a los menus necesarios que estan en utilities.php
menu("Listado de espacios", null);
menuUser();
session_write_close();

//Entra a este if, si existe el boton y es pulsado.
if (!empty($_POST["pagarEspacio-btn"])) {
    //Una funcion para poder realizar los pagos por los espacios alquilados
    include "vendor/redsysHMAC256_API_PHP_7.0.0/apiRedsys.php";
    $miObj = new RedsysAPI;

    $amount = $_POST['pago'];
    $url_tpv = ' https://sis-t.redsys.es:25443/sis/realizarPago';
    //$url_tpv ='https://sis.redsys.es/sis/realizarPago';

    //$clave = 'TU CLAVE DE COMERCIO'; //poner la clave SHA-256 facilitada por el banco8(Las siguientes variables las falicita el propio banco)
    $name = 'Guardamelo';
    $code = "999008881";
    //$code = 'TU CODIGO DE COMERCIO';
    $terminal = '1';
    $order = time();
    $amount = $amount * 100;
    $currency = '978';
    $consumerlng = '001';
    $transactionType = '0';
    $urlMerchant = ''; // Debe ser la url para enviar las notificaciones desde el TPV Virtual.
    $urlweb_ok = 'https://http://localhost/Practicas/Practica2/vendor/redsysHMAC256_API_PHP_7.0.0/ejemploRecepcionaPet.php';
    //$urlweb_ok = 'http://your-domain.com/tpv_ok.php'; //Debes crear una página para informar al usuario de que el pago se ha realizado correctamente.
    $urlweb_ko = 'https://localhost/Practicas/Practica2/vendor/redsysHMAC256_API_PHP_7.0.0/ejemploRecepcionaPet.php';
    //$urlweb_ko = 'http://your-domain.com/tpv_ko.php'; //. Debes crear una página para informar al usuario de que su pago ha sido erróneo.

    $miObj->setParameter("DS_MERCHANT_AMOUNT", $amount);
    $miObj->setParameter("DS_MERCHANT_ORDER", $order);
    $miObj->setParameter("DS_MERCHANT_MERCHANTCODE", $code);
    $miObj->setParameter("DS_MERCHANT_CURRENCY", $currency);
    $miObj->setParameter("DS_MERCHANT_TRANSACTIONTYPE", $transactionType);
    $miObj->setParameter("DS_MERCHANT_TERMINAL", $terminal);
    $miObj->setParameter("DS_MERCHANT_MERCHANTURL", $urlMerchant);
    $miObj->setParameter("DS_MERCHANT_URLOK", $urlweb_ok);
    $miObj->setParameter("DS_MERCHANT_URLKO", $urlweb_ko);
    $miObj->setParameter("DS_MERCHANT_MERCHANTNAME", $name);
    //$miObj->setParameter("DS_MERCHANT_CONSUMERLANGUAGE", $consumerlng);

    //Datos de configuración
    $version = "HMAC_SHA256_V1";
    $clave = 'sq7HjrUOBfKmC576ILgskD5srU870gJ7';

    $request = "";
    $params = $miObj->createMerchantParameters();
    $signature = $miObj->createMerchantSignature($clave);
?>


    <form action="<?php echo $url_tpv; ?>" method="post" target="_blank" name="formulario1" id="formulario">
        <input type='hidden' name='Ds_SignatureVersion' value='<?php echo $version; ?>'>
        <input type='hidden' name='Ds_MerchantParameters' value='<?php echo $params; ?>'>
        <input type='hidden' name='Ds_Signature' value='<?php echo $signature; ?>'>
        <input type="submit" value="Enviar">
    </form>
    <script>
        $(document).ready(function() {
            document.getElementById("formulario").submit();
        });
    </script>
<?php
} //fin de boton name="pagarEspacio-btn"


if (!empty($_POST["showNoPay-btn"])) {
    if ($_SESSION["rol"] == 1) {
        $member = new Member();
        unset($_SESSION["espacios"]); //destruye la variable que esta en la SESSION["caja]
        $espacios = $member->getAllEspaciosNoPagados(); //llama a la funcion getAllBoxes que se encuentra en la clase member.php
        if (!empty($espacios)) {
            $_SESSION["espacios"][] = $espacios;
        }
        $espacio = $_SESSION["espacios"];
    } else {
        //Entra con rol de usuario normal
        $member = new Member();
        unset($_SESSION["espacios"]);
        $espacios = $member->getEspacio($_SESSION["id"]);
        if (!empty($espacios)) {
            $_SESSION["espacios"][] = $espacios;
            $espacio = $_SESSION["espacios"];
        } else {
            $espacio = null;
        }
    }
}
if (!empty($_POST["showPay-btn"])) {
    if ($_SESSION["rol"] == 1) {
        $member = new Member();
        unset($_SESSION["espacios"]); //destruye la variable que esta en la SESSION["caja]
        $espacios = $member->getAllEspaciosPagados(); //llama a la funcion getAllBoxes que se encuentra en la clase member.php
        if (!empty($espacios)) {
            $_SESSION["espacios"][] = $espacios;
        }
        $espacio = $_SESSION["espacios"];
    } else {
        //Entra con rol de usuario normal
        $member = new Member();
        unset($_SESSION["espacios"]);
        $espacios = $member->getEspacioPagado($_SESSION["id"]);
        if (!empty($espacios)) {
            $_SESSION["espacios"][] = $espacios;
        }
        $espacio = $_SESSION["espacios"];
    }
}




if (!empty($_POST["confirmarEspacio-btn"])) {
    $member = new Member();
    $member->alternarEspacio($_POST["id"], 1);
}
if (!empty($_POST["borrarEspacio-btn"])) {
    $member = new Member();
    $member->alternarEspacio($_POST["id"], 2);
}

if (!empty($_POST["orderByEmailPay"])) {
    $member = new Member();
    $espacios = $member->getEspacioPagado($_POST["id-user"]);
    if (!empty($espacios)) {
        $_SESSION["espacios"][] = $espacios;
    }
    $espacio = $_SESSION["espacios"];
}

if (!empty($_POST["orderByEmailNoPay"])) {
    $member = new Member();
    $espacios = $member->getEspacio($_POST["id-user"]);
    if (!empty($espacios)) {
        $_SESSION["espacios"][] = $espacios;
    }
    $espacio = $_SESSION["espacios"];
}

?>
<!-- Formulario para mostrar el listado de espacios -->
<div class="d-flex flex-column min-vh-100 justify-content-center align-items-center" id="paddingMainDiv">
    <!-- Botones para mostrar pagados o no pagados -->
    <div id="datosUsuarioBlue" class="table-responsive" style="text-align: center;">
        <div class="container-fluid table-responsive">
            <form name="showForm" action="" method="post">
                <input type="submit" value="Mostrar espacios pagados" class="btn btn-danger" name="showPay-btn" id="showPay-btn">
                <input type="submit" value="Mostrar espacios no pagados" class="btn btn-danger" name="showNoPay-btn" id="showNoPay-btn">
            </form>
            <!-- Opciones de busqueda -->
            <?php if (!empty($_POST["showNoPay-btn"]) || !empty($_POST["showPay-btn"])) { ?>
                <div id="mostrarBusqueda">
                    <?php if ($_SESSION["rol"] == 1) { ?>
                        <h5>Ordenar por:</h5>
                        <select name="opcionBusqueda" id="opcionBusqueda" class="form-control" onchange="showFilter()">
                            <option value="eleccion" selected>Elige una opcion</option>
                            <option value="email">Correo electronico</option>
                            <option value="usuario">Usuario</option>
                            <option value="nombre">Nombre</option>
                        </select>
                    <?php } ?>
                    <!-- los botones de filtrado -->
                    <form action="" method="post" name="orderBy" id="showEmail" style="display:none">
                        <select name="id-user" class="form-control">
                            <option value="-1">Seleccione un usuario</option>
                            <?php
                            for ($i = 0; $i < count($usersArray); $i++) {
                                echo '<option value="' . $usersArray[$i]["id"] . '">' . $usersArray[$i]["id"] . ' - ' . $usersArray[$i]["email"] . '</option>'; //close your tags!!
                            }
                            ?>
                        </select>
                        <?php if (!empty($_POST["showNoPay-btn"])) { ?>
                            <input type="submit" name="orderByEmailNoPay" value="Ordenar por Email" class="btn btn-dark mt-3">
                        <?php }
                        if (!empty($_POST["showPay-btn"])) { ?>
                            <input type="submit" name="orderByEmailPay" value="Ordenar por Email" class="btn btn-dark mt-3">

                        <?php  } ?> 
                    </form>
                </div>
                <br>
            <?php } ?>
        </div>
    </div>
    <?php if (!empty($espacio)) {
        //Boton showNoPay
        if (!empty($_POST["showNoPay-btn"]) || !empty($_POST["orderByEmailNoPay"])) {
    ?>
            <!-- div para realizar busquedas filtrada y ordenada No pagados-->
            <div class="col-md-12 text-center mt-5 blue-color">
                <h1 class="welcome">¡Bienvenido a listado de espacios no pagados!</h1>
            </div>
        <?php } //fin button showNoPay
        //Button showPay
        else if (!empty($_POST["showPay-btn"]) || !empty($_POST["orderByEmailPay"])) {
        ?>
            <div class="col-md-12 text-center mt-5 blue-color">
                <h1 class="welcome">¡Bienvenido a listado de espacios pagados!</h1>
            </div>
        <?php } // fin button showPay
        ?>

        <div class="container-fluid table-responsive">
            <ul class="list-group">
                <?php
                $espacioAsignado = $espacio[0];
                for ($i = 0; $i < count($espacioAsignado); $i++) { ?>
                    <a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                        <!-- Div del Codigo de caja -->
                        <div class="flex-column">
                            <p><strong>ID:</strong></br>
                                <?php
                                print_r($espacioAsignado[$i]["id"]);
                                ?>
                            </p>
                            <p><strong>Medida:</strong></br>
                                <?php
                                print_r($espacioAsignado[$i]["medida"]);
                                ?> m²
                            </p>
                            <p><strong>Precio:</strong></br>
                                <?php
                                print_r($espacioAsignado[$i]["precio"]);
                                ?> €
                            </p>
                        </div>
                        <div class="flex-column">
                            <p><strong>Fecha:</strong></br>
                                <?php
                                print_r($espacioAsignado[$i]["fecha"]);
                                ?>
                            </p>
                            <p><strong>Pago confirmado:</strong></br>
                                <?php
                                print_r($espacioAsignado[$i]["pagoConfirmado"]);
                                ?>
                            </p>
                            <span class="badge badge-info badge-pill">User id:
                                <?php
                                print_r($espacioAsignado[$i]["userId"]);
                                ?>
                            </span>
                        </div>
                        <?php
            //*****************************BOTONES PARA REALIZAR LOS PAGOS DE ESPACIOS ASIGNADOS
                        if (!empty($_POST["showNoPay-btn"]) || !empty($_POST["orderByEmailNoPay"])) { //Para realizar el pago del espacio.
                            //Si entras con rol de administrador
                            if ($_SESSION["rol"] == 1) { ?>
                                <div class="flex-column">
                                    <button type="button" class="btn btn-primary" onclick="confirmacion(<?php print_r($i); ?>)"><i class="fa fa-money" aria-hidden="true"></i></button>
                                    <button type="button" class="btn btn-danger" onclick="borrar(<?php print_r($i); ?>)"><i class="fa fa-trash" aria-hidden="true"></i></button>
                                    <!-- Boton para confirmar el pago del espacio asignado a un id -->
                                    <div id="confirmar<?php print_r($i); ?>" name="div <?php print_r($i); ?>" style="display: none;">
                                        <p>¿Esta seguro de confirmar el pago con id <?php print_r($espacioAsignado[$i]["id"]); ?>?</p>
                                        <form name="confirmarEspacio" action="" method="post">
                                            <input type="text" name="id" value="<?php print_r($espacioAsignado[$i]["id"]); ?>" style="display: none;">
                                            <input type="submit" value="Si" class="btn btn-success" name="confirmarEspacio-btn">
                                            <button type="button" class="btn btn-warning" onclick="cancelar(<?php print_r($i); ?>)">No</button>
                                        </form>

                                    </div>
                                    <!-- Boton para cancelar el pago del espacio asignado con un id -->
                                    <div id="borrar<?php print_r($i); ?>" name="div <?php print_r($i); ?>" style="display: none;">
                                        <p>¿Esta seguro de borrar el pago con id <?php print_r($espacioAsignado[$i]["id"]); ?>?</p>
                                        <form name="borrarEspacio" action="" method="post">
                                            <input type="text" name="id" value="<?php print_r($espacioAsignado[$i]["id"]); ?>" style="display: none;">
                                            <input type="submit" value="Si" class="btn btn-success" name="borrarEspacio-btn">
                                            <button type="button" class="btn btn-warning" onclick="cancelarBorrado(<?php print_r($i); ?>)">No</button>
                                        </form>
                                    </div>
                                </div>

                            <?php } 
                            //Si entras con rol usuario
                            else if ($_SESSION["rol"] == 0) { ?>
                                <div class="flex-column">
                                    <form name="pagarEspacio" action="" method="post">
                                        <input type="text" name="pago" value="<?php print_r($espacioAsignado[$i]["precio"]); ?>" style="display: none;">
                                        <input type="submit" value="Pagar" class="btn btn-primary" name="pagarEspacio-btn">
                                    </form>
                                </div>
                            <?php }
                        }
                        //Si estas como administrador puedes borrar los espacios asignados
                        if ((!empty($_POST["showPay-btn"]) || !empty($_POST["orderByEmailPay"])) && $_SESSION["rol"] == 1) { ?>
                            <div class="flex-column">
                                <button type="button" class="btn btn-danger" onclick="borrar(<?php print_r($i); ?>)"><i class="fa fa-trash" aria-hidden="true"></i></button>
                                <div id="borrar<?php print_r($i); ?>" name="div <?php print_r($i); ?>" style="display: none;">
                                    <p>¿Esta seguro de borrar el pago con id <?php print_r($espacioAsignado[$i]["id"]); ?>?</p>
                                    <form name="borrarEspacio" action="" method="post">
                                        <input type="text" name="id" value="<?php print_r($espacioAsignado[$i]["id"]); ?>" style="display: none;">
                                        <input type="submit" value="Si" class="btn btn-success" name="borrarEspacio-btn">
                                        <button type="button" class="btn btn-warning" onclick="cancelarBorrado(<?php print_r($i); ?>)">No</button>
                                    </form>
                                </div>
                            </div>
                        <?php
                        }
                        ?>
                    </a>
                <?php  } ?>
                <!-- fin del for-->
            </ul>
        </div>
        <!-- Si entras con el rol de usuario rol=0 -->
    <?php } else { ?>
        <br>
        <div id="datosUsuario" class="table-responsive">
            <!-- Si entras con rol de administrador rol = 1 -->
            <?php if ($_SESSION["rol"] == 1) {
                if (!empty($_POST["showNoPay-btn"]) || !empty($_POST["showPay-btn"])) { ?>
                    <div class="col-md-12 text-center mt-5 blue-color">
                        <h1>Bienvenido a listado de espacios, al parecer todavia no hay espacios en la base de datos</h1>
                    </div>
                <?php } else { ?>
                    <div class="col-md-12 text-center mt-5 blue-color">
                        <h1>Bienvenido a listado de espacios, selecciona una opcion de arriba</h1>
                    </div>
                <?php } ?>
                <!-- Si entras con rol de usuario rol = 0 -->
                <?php } elseif ($_SESSION["rol"] == 0) {
                if (!empty($_POST["showNoPay-btn"]) || !empty($_POST["showPay-btn"])) { ?>
                    <div class="col-md-12 text-center mt-5 blue-color">
                        <h1><?php echo $nombre; ?>, al parecer todavia no hay espacios asignados con esta opcion.</h1>
                    </div>
                <?php } else { ?>
                    <div class="col-md-12 text-center mt-5 blue-color">
                        <h1>Bienvenido a listado de espacios, <?php echo $nombre; ?>, selecciona una opcion de arriba</h1>
                    </div>
            <?php }
            } ?>

        </div>
    <?php  } //fin $espacio 
    ?>
    <!-- fin del for que recorre la lista de espacios asignados  -->
</div>
<script>
    $(document).ready(function() {
        $(".jm-loadingpage").fadeOut("slow");
    });
//Funcion para borrar 
    function confirmacion($id) {
        var contenedor = document.getElementById("confirmar" + $id);
        contenedor.style.display = "block";
        return true;
    }

    function borrar($id) {
        var contenedor = document.getElementById("borrar" + $id);
        contenedor.style.display = "block";
        return true;
    }
//Funcion para cancelar
    function cancelar($id) {
        var contenedor = document.getElementById("confirmar" + $id);
        contenedor.style.display = "none";
        return true;
    }

    function cancelarBorrado($id) {
        var contenedor = document.getElementById("borrar" + $id);
        contenedor.style.display = "none";
        return true;
    }

    //Para los filtros de busqueda
    function mostrarPay() {
        document.getElementById("mostrarBusqueda").style.display = "block";
    }

    //Funcion para mostrar las opciones de busqueda que tiene el programa
    function showFilter() {
        let selectBox = document.getElementById("opcionBusqueda"); //recoge el select con este id
        let selectedValue = selectBox.options[selectBox.selectedIndex].value; //recoge el value del option que tiene el select
        if (selectedValue == "email") {
            document.getElementById("showEmail").style.display = "block"; //Muestra el email y las de mas opciones se anulan
            document.getElementById("showUsuario").style.display = "none";
            document.getElementById("showNombre").style.display = "none";
        } else if (selectedValue == "usuario") {
            document.getElementById("showUsuario").style.display = "block"; //Muestra el usuario 
            document.getElementById("showEmail").style.display = "none";
            document.getElementById("showNombre").style.display = "none";
        } else {
            document.getElementById("showNombre").style.display = "block"; //Muestra el nombre
            document.getElementById("showEmail").style.display = "none";
            document.getElementById("showUsuario").style.display = "none";
        }
    }
</script>
</BODY>
<?php
footer();
?>
</HTML>