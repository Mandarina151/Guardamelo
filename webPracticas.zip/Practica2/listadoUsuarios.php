<?php
require_once "utilities.php";

use Phppot\Member; //Checkinh up the variables that are necessary for enter to this file
//el rol administrador = 1, muestra todos los usuario de la base de datos
if (!empty($_SESSION["rol"])) {
    $rol = $_SESSION["rol"];
    if ($rol == 1) {
        require_once __DIR__ . '/lib/Member.php';
        $member = new Member();
        $users = $member->getAllUsers();
    } else {
        $url = "./index.php";
        header("Location: $url");
    }
} 
//EL rol de usuario = 0, no entra y te envia al index.php para registrarte o loguearte
else {
    $url = "./index.php";
    header("Location: $url");
}
//Calling the necessary menus. 
menu("Listado usuarios", null); //menu del head
menuUser(); //menu(utilities.php)
session_write_close(); //finaliza la sesión actual y almacena la información

//para el boton con value="delete-btn" para eliminar al usuario 
if (!empty($_POST["delete-btn"])) {
    require_once __DIR__ . '/lib/Member.php'; //llamamos a este archivo
    $member = new Member(); //instanciamos el archivo Member.php
    $deleteResult = $member->deleteMember(); //Llama a la función que esta en el archivo Member.php
}

?>
<div class="d-flex flex-column min-vh-100 justify-content-center align-items-center" id="paddingMainDiv">
    <?php if (!empty($users)) { ?>
        <?php
        if (!empty($_SESSION["msgDelete"])) {
        ?>
            <div class="alert alert-success"><?php echo $_SESSION["msgDelete"]; ?></div>
        <?php
            var_dump($_SESSION["msgDelete"]);
        }
        ?>
        <!-- Formulario para el listado de usuarios -->
        <div class="col-md-12 text-center mt-5 blue-color">
            <h1>Bienvenido al listado de usuarios!</h1>
        </div>
        <div class="container-fluid table-responsive">
            <ul class="list-group">
                <?php
                for ($i = 0; $i < count($users); $i++) { ?>
                    <a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                        <div class="flex-column">
                            <p> <strong>Nombre:</strong></br>
                                <?php
                                print_r($users[$i]["nombre"]);  //muestra nombre de usuario
                                ?>
                            </p>
                            <p><strong>Apellidos:</strong></br>

                                <?php
                                print_r($users[$i]["apellidos"]);//muestra apellido usuario
                                ?>
                            </p>
                            <p><strong>Teléfono:</strong></br>

                                <?php
                                print_r($users[$i]["telefono"]); //muestra telefono usuario
                                ?>
                            </p>
                        </div>
                        <div class="flex-column">
                            <!-- <p>Dirección:</br>
                                php//print_r($users[$i]["direccion"]);?>
                            </p>
                            <p>Creado:</br>
                                php//print_r($users[$i]["create_at"]);?>
                            </p> -->
                            <p><strong>E-mail:</strong></br>
                                <?php
                                print_r($users[$i]["email"]); //muestra email del usuario
                                ?>
                            </p>
                            <!-- Muestra el id del usuario -->
                            <span class="badge badge-info badge-pill"><strong>ID de usuario:</strong>
                                <?php
                                print_r($users[$i]["id"]);
                                ?> </span>
                        </div>
                        <!-- div para los buttons de modificar y eliminar usuario y la imagen en la seccion de listado de usuarios -->
                        <div class="flex-column">
                            <?php //TODO implementacion de modificacion al perfil de usuario. 
                            ?>
                            <button type="button" class="btn btn-primary"><i class="fa fa-pencil-square" aria-hidden="true"></i></button>
                            <button type="button" class="btn btn-danger" onclick="confirmacion(<?php print_r($i); ?>)"><i class="fa fa-trash" aria-hidden="true"></i></button>

                            <br>

                            <div id="confirmar<?php print_r($i); ?>" name="div <?php print_r($i); ?>" style="display: none;">
                                <p>¿Esta seguro de eliminar el usuario <?php print_r($users[$i]["nombre"]); ?>?</p>
                                <!-- Cuando el admin presiona SI para eliminar el usuario-->
                                <form name="deleteUser" action="" method="post">
                                    <input type="text" name="id" value="<?php print_r($users[$i]["id"]); ?>" style="display: none;">
                                    <input type="text" name="email" value="<?php print_r($users[$i]["email"]); ?>" style="display: none;">
                                    <input type="submit" value="Si" class="btn btn-danger" name="delete-btn">
                                    <button type="button" class="btn btn-danger" onclick="cancelar(<?php print_r($i); ?>)">No</button>

                                </form>
                            </div>
                        </div>
                        <?php //TODO implementacion de imagen dinamica para el usuario. 
                        ?>
                        <div class="image-parent">
                            <img class="img-fluid" alt="Imagen de usuario" height="200" width="200" src="">
                        </div>
                    </a>
                <?php  } ?> <!--fin del for que sirve para listar a todos los usuarios -->
            </ul>

        </div>
    <?php } ?>
</div>
<script>
    //Función para recargar la pagina
    $(document).ready(function() {
        $(".jm-loadingpage").fadeOut("slow");
    });
    //Función para confirmar si queremos borrar al usuario
    function confirmacion($id) {
        var contenedor = document.getElementById("confirmar" + $id);
        contenedor.style.display = "block";
        return true;
    }
    //Función para cancelar la eliminación de un usuario 
    function cancelar($id) {
        var contenedor = document.getElementById("confirmar" + $id);
        contenedor.style.display = "none";
        return true;
    }
</script>
</BODY>
<?php
footer(); //llama a esta funcion que esta en el archivo utilities.php

?>

</HTML>