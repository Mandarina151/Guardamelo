<?php
require_once "utilities.php"; //llama al archivo utilities.php
if (!empty($_SESSION["email"])) { // si es diferente de vacio
	$email = $_SESSION["email"];
	$apellidos = $_SESSION["apellidos"];
	$telefono = $_SESSION["telefono"];
	//$direccion = $_SESSION["direccion"];
	$nombre = $_SESSION["nombre"];
	$rol = $_SESSION["rol"];
} else { //si esta vacio cierras la sesión y lo redireccionas al index.php
	session_unset();
	$url = "./index.php";
	header("Location: $url");
}

menu("Modificar Datos", null); //Llama al menú que esta en utilities.php
menuUser();//Llama al menu de usuario que esta en utilities.php

?>
<div class="d-flex flex-column min-vh-100 justify-content-center align-items-center" id="template-bg-3">
	<?php
	if (!empty($_SESSION["msgRegistro"])) {
	?>
		<div class="alert alert-success"><?php echo $_SESSION["msgRegistro"]; ?></div>
	<?php
		$_SESSION['msgRegistro'] = null;
	}
	?>
	<!-- Call the logo of Guardamelo in the file images -->
	<img src="images/logo_Guardamelo.png" alt="Logo de guardamelo">
	<!-- Div para modificar los datos del usuario -->
	<div class="card mb-5 p-5 text-white" id="orange-modify">
		<div class="col-md-100">
			<div class="text-center">
				<h3 id="titleModify">Modificar Datos</h3>
			</div>
			<div class="modifyDates mt-3">
				<!-- Formulario para modificar los datos de usuario -->
				<form name="modifyData" action="" method="post">
					<table>
						<!-- Email -->
						<tr>
							<td>
								<i class="fa fa-envelope pb-3"></i>
							</td>
							<td class="w-100 pb-3 pl-1">
								<input type="text" class="form-control p-3" placeholder="E-mail *" name="email" value="<?php echo $_SESSION["email"] ?>">
							</td>
						</tr>
						<!-- Phone -->
						<tr>
							<td>
								<i class="fa fa-phone pb-3"></i>
							</td>
							<td class="w-100 pb-3 pl-1">
								<input type="text" class="form-control p-3" placeholder="Telefono *" name="telefono" value="<?php echo $_SESSION["telefono"] ?>">
							</td>
						</tr>
						<!-- Address -->
						<!-- <tr>
							<td>
								<i class="fa fa-home pb-3"></i>
							</td>
							<td class="w-100 pb-3 pl-1">
								<input type="text" class="form-control p-3" placeholder="Dirección *" name="direccion" value="<?php //echo $_SESSION["direccion"] ?>">
							</td>
						</tr> -->
						<!-- Password -->
						<tr>
							<td>
								<i class="fa fa-key pb-3"></i>
							</td>
							<td>
								<input type="password" class="form-control p-3" placeholder="contraseña *" name="password" value="<?php echo $_SESSION["password"] ?>">
							</td>
						</tr>
					</table>
					<!-- Boton de modificar -->
					<div class="text-center">
						<input type="submit" value="Modificar" class="btn mt-3 w-100 p-2" name="modify-btn" id="boton-modify">
					</div>

				</form>
				<?php if (!empty($loginResult)) { ?>
					<br>
					<input type="button" value="<?php echo $loginResult; ?>" class="btn mt-3 w-100 p-1 bg-warning text-dark" disabled>

					<div class="bg-warning text-danger" <?php echo $loginResult; ?>></div>
				<?php } ?>
			</div>
		</div>
	</div> <!-- fin del div para modificar los datos del usuario -->

</div>
<script>
	$(document).ready(function() {
		$(".jm-loadingpage").fadeOut("slow");
	});
</script>
</body>
<!-- Llama a la funcion footer que esta en utilities.php -->
<?php
footer();
?>