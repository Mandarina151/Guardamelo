<?php
require_once "utilities.php"; //Llama al archivo utilities.php
//el rol administrador = 1, entras como admin para modificar tus datos de admin
if (!empty($_SESSION["rol"])) {
    $rol = $_SESSION["rol"];
    if ($rol == 1) {
    } else { //si no tienes el email registrado lo redireccionas a index.php
        $url = "./index.php";
        header("Location: $url");
    }
} else {
//rol de usuario = 0
    $url = "./index.php";
    header("Location: $url");
}
menu("Datos administrador", null); //Call the menu where is the menu head
menuUser();//Call the Administrator menu that is in utilities.php


?>
<?php
//Declaracion de variables usadas para validar inputs cuando Admin modifica datos
$nombre = $apellidos = $email = $movil = "";
$errorNombre = $errorApellidos = $errorEmail = $errorMovil = "";

//Button of Modificar
if(isset($_POST["modify-btn"])){
    $nombre = testInput($_POST["nombre"]); //Declaración de la variable $nombre
    $apellidos = testInput($_POST["apellidos"]);//Declaración de la variable $apellidos
    

/******************************VALIDACION DEL NOMBRE************************************************* */
    if (empty($nombre)) {
        $flag = true;
        $errorNombre = "The name is not empty";
    } else if (preg_match("/[()\d]/", $nombre)) {
        $flag = true;
        $errorNombre = "The name not contain numbers";
    }
/******************************VALIDACION DE APELLIDOS************************************************* */
    if (empty($apellidos)) {
        $flag = true;
        $errorApellidos = "The lastname is not empty";
    } else if (preg_match("/[()\d]/", $apellidos)) {
        $flag = true;
        $errorApellidos = "The lastname not contain numbers";
    }
/*******************************VALIDACION DEL EMAIL************************************************ */
    $recrex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';
    if(empty($email)){
        $flag=true;
        $errorEmail = "The email is not empty";
    } else if(!preg_match($recrex, $email)){
        $flag = true;
        $errorEmail = "It does not have an email format";
    }
/********************************VALIDACION DEL NUMERO DE MOVIL*************************************/
    $regExpMovil = "/^[0-9]{9,9}$/";
    if(empty($movil)){
        $flag = true;
        $errorMovil = "The phone should not be empty";
    }else if(!preg_match($regExpMovil,$movil)){
        $flag = true;
        $errorMovil = "The phone number must have 9 numbers";
    }else{
        $errorMovil = "";
    }
    
    

// !!!!! FALTA VALIDAR LOS DEMAS DATOS DEL FORMULARIO, NUMERO DE TELEFONO Y PASSWORD !!!!!!



}//fin de boton modify-btn (modificar datos de administrador)

?>
<!-- div containing the administrator form to modify user data-->
<!-- div que contiene el formulario de administrador para modificar los datos del usuario -->
<div class="d-flex flex-column min-vh-100 justify-content-center align-items-center" id="template-bg-3">
    <?php
    if (!empty($_SESSION["msgRegistro"])) {
    ?>
        <div class="alert alert-success"><?php echo $_SESSION["msgRegistro"]; ?></div>
    <?php
        $_SESSION['msgRegistro'] = null;
    }
    ?>
    <!-- Call the logo of Guardamelo in the file images -->
    <img src="images/logo_Guardamelo.png" alt="Logo de guardamelo">
    <!-- Div para el formulario de modificar datos del administrador -->
    <div class="card mb-5 p-5 text-white" id="orange-modify">
        <div class="col-md-100">
            <div class="text-center">
                <h3 id="titleModify">Modificar Datos Administrador</h3>
            </div>
            <div class=" mt-3">
                <form name="modifyDataAdmin" action="" method="post">
                    <table>
                        <!-- Name -->
                        <tr>
                            <td>
                                <i class="fa fa-user pb-3"></i>
                            </td>
                            <td class="w-100 pb-3">
                                <input type="text" class="form-control p-3" placeholder="Nombre *" name="nombre" value="<?php echo $_SESSION["nombre"] ?>">
                                <span class="text-danger"><?php echo $errorNombre ?></span>
                            </td>
                        </tr>
                        <!-- LastName -->
                        <tr>
                            <td>
                                <i class="fa fa-user-plus pb-3"></i>
                            </td>
                            <td class="w-100 pb-3">
                                <input type="text" class="form-control p-3" placeholder="Apellidos *" name="apellidos" value="<?php echo $_SESSION["apellidos"] ?>">
                                <span class="text-danger"><?php echo $errorApellidos ?></span>
                            </td>
                        </tr>
                        <!-- Email -->
                        <tr>
                            <td>
                                <i class="fa fa-envelope pb-3"></i>
                            </td>
                            <td class="w-100 pb-3">
                                <input type="text" class="form-control p-3" placeholder="E-mail *" name="email" value="<?php echo $_SESSION["email"] ?>">
                                <span class="text-danger"><?php echo $errorEmail ?></span>
                            </td>
                        </tr>
                        <!-- Phone -->
                        <tr>
                            <td>
                                <i class="fa fa-phone pb-3"></i>
                            </td>
                            <td class="w-100 pb-3">
                                <input type="text" class="form-control p-3" placeholder="Teléfono *" name="telefono" value="<?php echo $_SESSION["telefono"] ?>">
                                <span class="text-danger"><?php echo $errorMovil ?></span>
                            </td>
                        </tr>
                        <!-- Address -->
                        <!-- <tr>
                            <td>
                                <i class="fa fa-home pb-3"></i>
                            </td>
                            <td class="w-100 pb-3">
                                <input type="text" class="form-control pb-3" placeholder="Dirección *" name="direccion"  value="<?php echo $_SESSION["direccion"] ?>">
                            </td>
                        </tr> -->
                        <!-- Password -->
                        <tr>
                            <td>
                                <i class="fa fa-key pb-3"></i>
                            </td>
                            <td class="w-100 pb-3">
                                <input type="password" class="form-control p-3" placeholder="Contraseña *" name="password" value="<?php echo $_SESSION["password"] ?>">
                            </td>
                        </tr>
                    </table>
                    <div class="text-center">
                        <input type="submit" value="Modificar" class="btn mt-3 w-100 p-2" name="modify-btn" id="boton-modify">
                    </div>
                </form>
                <?php if (!empty($loginResult)) { ?>
                    <br>
                    <input type="button" value="<?php echo $loginResult; ?>" class="btn mt-3 w-100 p-1 bg-warning text-dark" disabled>

                    <div class="bg-warning text-danger" <?php echo $loginResult; ?>></div>
                <?php } ?>
            </div>
        </div>
    </div> <!-- Fin del div del formulario para modificar datos del administrador-->
</div>
<script>
    $(document).ready(function() {
        $(".jm-loadingpage").fadeOut("slow");
    });
</script>
<!-- Call the footer on the file utilities.php -->
<?php
footer();
?>