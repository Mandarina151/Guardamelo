<?php
require_once "utilities.php"; //Llama a este archivo php
require_once __DIR__ . '/lib/Member.php'; //llama a este archivo php

use Phppot\Member;

//Checkinh up the variables that are necessary for enter to this file
// Verifica las variables que son necesarias para ingresar a este archivo
if (!empty($_SESSION["email"])) {
	//Entra con rol administrador
	if ($_SESSION["rol"] == 1) {
		$member = new Member(); //Creamos una instancia de la clase Memebr
		unset($_SESSION["caja"]); //destruye la variable que esta en la SESSION["caja]
		$boxes = $member->getAllBoxes(); //llama a la funcion getAllBoxes que se encuentra en la clase member.php
		if (!empty($boxes)) {
			$_SESSION["caja"][] = $boxes;
		}
		$caja = $_SESSION["caja"];
	} else {
	//Entra con rol de usuario normal
		$member = new Member(); //creamos una instancia de la clase Member
		unset($_SESSION["caja"]);//destruye la variable que esta en la SESSION["caja]
		$boxes = $member->getBox($_SESSION["id"]);
		if (!empty($boxes)) {
			$_SESSION["caja"][] = $boxes;
		}
		$caja = $_SESSION["caja"];
	}
	$nombre = $_SESSION["nombre"];
} else {
	session_unset();
	$url = "./index.php";
	header("Location: $url");
}
//Llama a los menus necesarios para utilizar en este archivo
menu("Listado de cajas", null);
menuUser();
session_write_close();

//Entra a este if, si existe cajas en la base de datos
if (!empty($_POST["deleteBox-btn"])) {
	require_once __DIR__ . '/lib/Member.php';
	$member = new Member();
	$member->deleteBox();
}
?>
<!-- Formulario para mostrar el listado de cajas -->
<div class="d-flex flex-column min-vh-100 justify-content-center align-items-center" id="paddingMainDiv">
	<!-- Entra a este if si existen cajas en la base de datos -->
	<?php if (!empty($caja)) { ?>
		<div class="col-md-12 text-center mt-5 blue-color">
			<h1 class="welcome">Bienvenido a listado de cajas, <?php echo $nombre; ?>!</h1>
		</div>
		<div class="container-fluid table-responsive">
			<ul class="list-group">
				<?php
				$cajas = $caja[0];
				//For que recorre la lista de cajas que tiene cada usuario
				for ($i = 0; $i < count($cajas); $i++) { ?>
					<a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
						<!-- Div del Codigo de caja -->
						<div class="flex-column">
							<strong>Codigo de caja:</strong>
							<p><small>
									<?php
									print_r($cajas[$i]["codigo_caja"]); //Muestra el codigo de caja
									?>
								</small></p>
							<span class="badge badge-info badge-pill">User id:
								<?php
								print_r($cajas[$i]["userId"]); //Muestra el id del usuario
								?> </span>
						</div>
						<!-- Si el usuario tiene rol de administrador muestra este menu para eliminar cajas -->
						<?php if ($_SESSION["rol"] == 1) { ?>
							<div class="flex-column">
								<button type="button" class="btn btn-primary"><i class="fa fa-pencil-square" aria-hidden="true"></i></button>
								<button type="button" class="btn btn-danger" onclick="confirmacion(<?php print_r($i); ?>)"><i class="fa fa-trash" aria-hidden="true"></i></button>
							</div>
							<div class="flex-column" id="confirmar<?php print_r($i); ?>" name="div <?php print_r($i); ?>" style="display: none;">
								<p>¿Esta seguro de eliminar la caja <?php print_r($cajas[$i]["codigo_caja"]); ?>?</p>
								<form name="deleteBox" action="" method="post">
									<input type="text" name="codigo_caja" value="<?php print_r($cajas[$i]["codigo_caja"]); ?>" style="display: none;">
									<input type="text" name="userId" value="<?php print_r($cajas[$i]["userId"]); ?>" style="display: none;">
									<input type="submit" value="Si" class="btn btn-danger" name="deleteBox-btn">
								</form>
								<button type="button" class="btn btn-danger" onclick="cancelar(<?php print_r($i); ?>)">No</button>
							</div>
						<?php } ?> <!--fin del div que usa al rol administrador p eliminar cajas de los usuarios-->
						<div class="image-parent">
							<img src="images/userImage/<?php print_r($cajas[$i]["Foto"]); ?>" class="img-fluid" alt="Imagen de caja" height="200" width="200">
						</div>
					</a>
				<?php  } ?>  <!-- fin del for que recorre la lista de cajas  -->
			</ul>
		</div>
	<?php
	//Entra a este else si no hay cajas en la base de datos
	} else { ?>
		<div id="datosUsuario" class="table-responsive">
			<!-- Si entras con rol de administrador rol = 1 -->
			<?php if ($_SESSION["rol"] == 1) { ?>
				<div class="col-md-12 text-center mt-5 blue-color">
					<h1>Bienvenido a listado de cajas, al parecer todavia no hay cajas en la base de datos!</h1>
				</div>
			<!-- Si entras con rol de usuario rol = 0 -->
			<?php } elseif ($_SESSION["rol"] == 0) { ?>
				<div class="col-md-12 text-center mt-5 blue-color">
					<h1>Bienvenido a listado de cajas, <?php echo $nombre; ?>, al parecer todavia no tienes cajas en Guardamelo</h1>
				</div>
			<?php } ?>

		</div>

	<?php
	}
	?>
</div>
<script>
	$(document).ready(function() {
		$(".jm-loadingpage").fadeOut("slow");
	});
	//Funcion JS para confirmar si el admin desea eliminar una caja de cualquier usuario
	function confirmacion($id) {
		var contenedor = document.getElementById("confirmar" + $id);
		contenedor.style.display = "block";
		return true;
	}
	//Funcion JS para cancelar si no quiere eliminar una caja de 
	function cancelar($id) {
		var contenedor = document.getElementById("confirmar" + $id);
		contenedor.style.display = "none";
		return true;
	}
</script>
</BODY>
<?php
footer(); //Llama a la funcion footer que se encuentra en el archivo utilities.php

?>

</HTML>