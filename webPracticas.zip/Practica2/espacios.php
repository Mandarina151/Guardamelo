<?php
require_once "utilities.php"; //importamos este archivo para reutilizarlo

use Phppot\Member;

//Para entrar segun el rol (este caso rol = adminsitrador)
if (!empty($_SESSION["rol"])) {
    $rol = $_SESSION["rol"];
    if ($rol == 1) {
    } else {
        $url = "./index.php";
        header("Location: $url");
    }
} else {
    $url = "./index.php";
    header("Location: $url");
}
require_once __DIR__ . '/lib/Member.php'; //Llama al archivo Member.php
$users = new Member();
$usersArray = $users->getAllUsers(); //Llama a la función que esta en Member.php (lista a todos los usuarios)

menu("Espacios", "register.css"); //llama a la funcion menu(contiene head) del archivo utilities.
menuUser(); //Call the Administrator menu that is in utilities.php

/***************************VALIDACION DEL CAMPO PRECIO ************************************************** */
$precio = $espacio = $idUser = $espacioCreado = "";
$errorPrecio = $errorEspacio = $errorIdUser =  "";
$check = true;

//Cuando se presiona el boton de PAGAR
if (isset($_POST["pagar"])) {
    $precio = testInput($_POST["precio"]);
    $espacio = testInput($_POST["medida"]);
    $idUser = testInput($_POST["id-user"]);
    
    //Comprobando el id user 
    if ($idUser==-1) {
        $errorIdUser  = "Debes seleccionar un usuario";
        $check = false;
    }


    if ($espacio==-1) { #Validamos que el input del precio no este vacio
        $errorEspacio = "Debes seleccionar un espacio";
        $check = false;
    } else {
        if ($espacio == 0) {
            $espacio = testInput($_POST["medidaPerso"]);
            if (empty($espacio)){
                $errorEspacio = "La medida personalizada no puede estar vacia.";
                $check = false;
            }
            else if(!preg_match("/^\d+(\.(\d{2}))?$/", $espacio)){
                $errorEspacio = "La medida personalizada debe ser un número(si es con decimales debe llevar un . y con dos decimales como minimo)";
                $check = false;
            }
        } 
    }


    if (empty($precio)) { #Validamos que el input del precio no este vacio
        $errorPrecio = "Debes introducir un precio.";
        $check = false;
    }elseif ($precio == 0) {
        $errorPrecio = "El precio no puede ser 0.";
        $check = false;
    } 
    else if (!preg_match("/^\d+(\.(\d{2}))?$/", $precio)) { #Validamos que el input sean solo números
        $errorPrecio = "El precio debe ser un número(si es con decimales debe llevar un . y con dos decimales como minimo)";
        $check = false;
    }

    if($check==true){
        require_once __DIR__ . '/lib/Member.php';
        $member = new Member();
        $member->crearEspacio($idUser,$espacio,$precio);
        $espacioCreado = "espacio creado correctamente";
    }
} //Fin del boton pagar 
?>
<!-- ******************************FORMULARIO DE AÑADIR ESPACIO ********************************** -->
<div class="d-flex flex-column min-vh-100 justify-content-center align-items-center" id="register-box">
    <!-- Si la query nos devuelve el array vacio  -->
    <?php
    if (empty($usersArray)) {
    ?>
        <div class="alert alert-danger">Error en la conexión sql</div>
    <?php
    }
    ?>
    <?php
    if ($check == false) {
    ?>
        <div class="alert alert-danger"> Por favor, revise los errores marcados. </div>
    <?php
    }
    ?>
    <?php
    if (!empty($espacioCreado)) {
    ?>
        <div class="alert alert-success"> <?php  echo $espacioCreado ?> </div>
    <?php
    }
    ?>
    <img src="images/logo_Guardamelo.png" alt="Logo de guardamelo">
    <div class="row">
        <div class="container col-11 col-sm-8 col-md-10 col-lg-10 formulario">
            <form class="form-horizontal" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <h1 class="text-center m-5">Asignación de espacio</h1>
                <p class="text-white ml-4">* Campos obligatorios</p>
                <!-- Select para seleccionar un usuario de la base de datos -->
                <div class="input-group form-group mt-3">
                    <select name="id-user" class="form-control">
                        <option value="-1">Seleccione un usuario</option>
                        <?php
                        for ($i = 0; $i < count($usersArray); $i++) {
                            echo '<option value="' . $usersArray[$i]["id"] . '">' . $usersArray[$i]["id"] . ' - ' . $usersArray[$i]["email"] . '</option>'; //close your tags!!
                        }
                        ?>
                    </select>
                </div>
                <span class="text-danger"> <?php echo $errorIdUser ?></span>

                <!-- Select para seleccionar la medida del espacio o medida personalizada -->
                <div class="input-group form-group mt-3">
                    <select name="medida" class="form-control" id="espacioElegido" onchange="changeFunc()">
                        <option value="-1">Elige tu espacio</option>
                        <option value="1">1 m²</option>
                        <option value="2">2 m²</option>
                        <option value="3">3 m²</option>
                        <option value="4">4 m²</option>
                        <option value="5">5 m²</option>
                        <option value="6">6 m²</option>
                        <option value="7">7 m²</option>
                        <option value="8">8 m²</option>
                        <option value="9">9 m²</option>
                        <option value="0">Espacio personalizado</option>
                        <span class="text-danger"> <?php echo $errorEspacio ?></span>
                    </select>
                </div>
                <!-- Espacio personalizado -->
                <div class="mt-3">
                    <div>
                        <input type="text" min="0" style="display:none" id="espacio" class="form-control" name="medidaPerso" placeholder="Espacio que necesitas *" value="<?php echo $espacio ?>">
                        <span class="text-danger"> <?php echo $errorEspacio ?></span>
                    </div>
                </div>
                <!-- Precio por pagar validado -->
                <div>
                    <div class="mt-3">
                        <input type="text" min="0" class="form-control" name="precio" placeholder="Precio a pagar *" value="<?php echo $precio ?>">
                        <span class="text-danger"> <?php echo $errorPrecio ?></span>
                    </div>
                </div>
                <!-- Boton para realizar pago -->
                <div class="container mb-5 mt-5 registrar">
                    <input type="submit" name="pagar" value="Crear espacio" class="btn btn-lg btn-block">
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {  
        $(".jm-loadingpage").fadeOut("slow");
    });
    //Para el espacio personalizado usamos JavaScript
    function changeFunc() {
        var selectBox = document.getElementById("espacioElegido"); //guardamos la elección que tiene el select
        var selectedValue = selectBox.options[selectBox.selectedIndex].value; //recogemos el valor que tiene una option del select
        if (selectedValue == 0) { //Si el value del select = 0, significa que elegio el espacio personalizado
            document.getElementById("espacio").style.display = "block"; //muestra el input para colocar el espacio que necesita
        } else {
            document.getElementById("espacio").style.display = "none"; //Cualquier otro caso, este input se esconde
        }
    }
</script>
</body>
<?php
footer();
?>
</html>