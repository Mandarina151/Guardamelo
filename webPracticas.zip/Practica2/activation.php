<?php
//Llama al archivo php para ser utilizado en este archivo
require_once "utilities.php";

use Phppot\Member;

require_once __DIR__ . '/lib/Member.php';
$member = new Member();

menu("Activacion de correo", ""); //Llama a la funcion menu que esta en el archivo utilities.php
menuNoUser(); //Menu para no usuario

$msg = '';
if (!empty($_GET['code']) && isset($_GET['code'])) {
    $code =  $member->convertString($_GET['code']);
    $c = $member->getMemberByCode($code);

    if (!empty($c)) {
        $count = $member->getMEmberByCodeStatus($code);
        //Compruebe si solo hay un miembro en la matriz
        $flag = 0;
        for ($i = 0; $i < count($count); $i++) {
            $flag++;
        }
        if ($flag == 1) {
            $member->confirmMember($code);
            $msg = "Your account is activated";
        } else {
            $msg = "Your account is already active, no need to activate again";
        }
    } else {
        $msg = "Wrong activation code.";
    }
}else{
    session_unset();
	$url = "./index.php";
	header("Location: $url");
}
//HTML Part------------------Parte del HTML-----------------
?>
<div class="d-flex flex-column min-vh-100 justify-content-center align-items-center" id="paddingMainDiv">
    <div id="datosUsuario" class="table-responsive">
        <div class="col-md-12 text-center mt-5 blue-color">
            <?php echo $msg; ?>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $(".jm-loadingpage").fadeOut("slow");
    });
</script>
</body>
<?php
footer();
?>
</html>