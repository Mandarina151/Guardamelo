<?php
//Redirigiendo al usuario en caso de que acceda a este fichero.
if(count(get_included_files()) ==1){
  $url = "./index.php";
  header("Location: $url");
};
//utilities will have a session_start in all the files to have not to iniciate every time we need a session.
session_start();
//the next function will have a basic structure for every file we need to use.
//la siguiente función tendrá una estructura básica para cada archivo que necesitemos usar.
function menu($title, $css)
{
  if ($css != null) {
    $menu = <<<HER
    <!doctype html>
    <html lang="es">
      <head>
        <!-- Required meta tags -->
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- css-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css" crossorigin="anonymous">
        <link rel="stylesheet" href="vendor/style.css">
        <link rel="stylesheet" href="vendor/$css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
        <!-- jquery-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <!-- js-->
        <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
        <!-- Name os sites and setting up the favico-->
        <link rel="icon" type="image/png" href="images/icon_Guardamelo.png">
        <title>$title</title>
      </head>
    
    HER;
    echo $menu;
  } else { //Funcion para el head de la aplicación
    $menu = <<<HER
    <!doctype html>
    <html lang="es">
      <head>
        <!-- Required meta tags -->
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- css-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css" crossorigin="anonymous">
        <link rel="stylesheet" href="vendor/style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
        <!-- jquery-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <!-- js-->
        <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
        <!-- Name os sites and setting up the favico-->
        <link rel="icon" type="image/png" href="images/icon_Guardamelo.png">
        <title>$title</title>
      </head>
      <body>
    
    HER;
    echo $menu;
  }
}


//The following function will show a menu depending on the role assigned to the $ _Session ["role]
//EL menuUser sera igual para el menuAdmin
// La siguiente función mostrará un menú dependiendo del rol asignado al $ _Session ["rol]
// EL menuUser sera igual para el menuAdmin
function menuUser()
{
  $menu = <<<HER
  <body class="bg-image">
  <div class="jm-loadingpage"></div> 
  <nav role="navigation" class="navbar navbar-expand-lg navbar-dark bg-light">
    <div id="navButton" class="navbar-header">
      <button id="botonMenu" type="button" class="navbar-toggle icon ion-android-menu " data-toggle="collapse" data-target="#navbarCollapse"></button>
      <a class="navbar-brand" href="http://localhost/Practicas/wordpress/"><img src="images/logo_Guardamelo.png" alt="Logo de guardamelo"></a>
    </div>

    <!-- Collection of nav links and other content for toggling -->
    <div id="navbarCollapse" class="collapse navbar-collapse">
      <ul class="nav navbar-nav topnav ml-auto">
        <li class="color_li"><a class="nav-link" id="orange-color" href="index.php">Inicio</a></li>
        <li> <a class="nav-link" id="orange-color" href="herramientas.php">Herramientas</a></li>
        <li class="color_li"> <a class="nav-link" id="orange-color" href="http://localhost/Practicas/wordpress/"  target="_blank">Web principal</a></li>
        <li class="color_li"> <a class="nav-link" id="orange-color" href="logout.php">Logout</a></li>
      </ul>
    </div>
  </nav>

HER;
  echo $menu;
}

// La siguiente función mostrará un menú dependiendo del rol asignado al $ _Session ["rol]
function menuNoUser()
{
  $menu = <<<HER
  <body class="bg-image">
  <div class="jm-loadingpage"></div>
  <nav role="navigation" class="navbar navbar-expand-lg navbar-dark bg-light">

  <div id="navButton2" class="navbar-header">
    <button id="botonMenu2" type="button" class="navbar-toggle icon ion-android-menu " data-toggle="collapse" data-target="#navbarCollapse"></button>
    <a class="navbar-brand" href="http://localhost/Practicas/wordpress/"><img src="images/logo_Guardamelo.png" alt="Logo de guardamelo"></a>
  </div>

  <!-- Collection of nav links and other content for toggling -->
  <div id="navbarCollapse" class="collapse navbar-collapse">
    <ul class="nav navbar-nav topnav ml-auto">
    <li><a class="nav-link" id="orange-color" href="index.php">Inicio</a></li>
    <li> <a class="nav-link" id="orange-color" href="http://localhost/Practicas/wordpress/"  target="_blank">Web principal</a></li>
    </ul>
  </div>
</nav>
HER;
  echo $menu;
}


//Funcion donde se implementa el footer de la aplicación
function footer()
{
  $menu = <<<HER
  <div class="footer-basic" id="blue-box">
  <footer> 
      <div class="social">
        <a href="#"><i class="icon ion-social-instagram"></i></a>
        <a href="#"><i class="icon ion-social-twitter"></i></a>
        <a href="#"><i class="icon ion-social-facebook"></i></a>
      </div>
      <div class="social">
        <p class="icon ion-android-call"> 633 819 158</p>
      </div>
      <ul class="list-inline">
          <li class="list-inline-item"><a href="#">Servicio</a></li>
          <li class="list-inline-item"><a href="#">Sobre nosotros</a></li>
          <li class="list-inline-item"><a href="#">Terminos</a></li>
          <li class="list-inline-item"><a href="#">Politicas de privacidad</a></li>
      </ul>
      <p class="copyright">Guardamelo © 2018</p>
  </footer>
</div>
HER;
  echo $menu;
}

//función para limpiar el texto que viene desde el formulario
function testInput($input)
{
  $returned = htmlspecialchars(trim($input)); //htmlspecialchars:invalida los simbolos problematicos de HTML
  return $returned;
}
