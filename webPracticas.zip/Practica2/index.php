<?php
require_once "utilities.php";
//Once the page is loaded, will get some structure by the next function.
//Una vez que la página está cargada, la siguiente función obtendrá cierta estructura.
menu("Inicio de sesion", null); //Llama a esta funcion
menuNoUser(); //llama a esta funcion para mostrar este menu de no usuario
use Phppot\Member; //LLama a la clase member.php que esta en la carpeta lib
//Now if theres is a session is iniciated will show the rol structure(for both cases admin/cliente)
//Ahora si hay una sesión iniciada se mostrará la estructura del rol (para ambos casos admin / cliente)
if (isset($_SESSION["email"])) {
    header('Location: ./loggedIn.php');
} //But if the user is not registered or not loged, will show the initial menu.
//Pero si el usuario no está registrado o no está registrado, se mostrará el menú inicial
if (!empty($_POST["login-btn"])) {
    require_once __DIR__ . '/lib/Member.php';
    $member = new Member(); //Creamos un nuevo objeto de la clase Member
    $loginResult = $member->loginMember();
}


?>
<?php
if (!empty($_GET["i"])) {
    $template = intval($_GET["i"]);
}

if (empty($template)) {
    $template = 3;
}

require_once __DIR__ . '/template/login-template' . $template . '.php';

?>
<script>
    $(document).ready(function() {
        $(".jm-loadingpage").fadeOut("slow");
    });
</script>
</body>

<?php
footer();

?>

</html>