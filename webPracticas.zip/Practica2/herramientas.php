<?php
require_once "utilities.php";
//el rol administrador = 1
if (!empty($_SESSION["email"])) {
    $rol = $_SESSION["rol"];
} else {
    $url = "./index.php";
    header("Location: $url");
}
menu("Herramientas", null); //Call the menu where is the menu head
menuUser();


?>
<!-- div que contiene el administrador para mostrar todas las herramientas que se pueden utilizar-->
<div class="d-flex flex-column min-vh-100 justify-content-center align-items-center" id="template-bg-3">
    <!-- Llamar al logo de Guardamelo en las imágenes de archivo -->
    <img src="images/logo_Guardamelo.png" alt="Logo de guardamelo">
    <div class="card mb-5 p-5 text-white" id="orange-modify">
        <div class="col-md-100">
            <div class="text-center">
                <h3 id="titleModify">Herramientas</h3><!--Titulo con bootstrap -->
            </div>
            <div class=" mt-3">
            <!-- Si el rol = 1, significa que esta logueado como administrador muestra este menu-->
                <?php if ($rol == 1) { ?>
                    <table>
                        <tr>
                            <td>
                                <a href="modifyDatesAdmin.php" class="orange-color" id="toolLink"><i class="fa fa-pencil-square-o" aria-hidden="true"> Modificar datos del admin</i></a>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <a href="uploadFile.php" class="orange-color" id="toolLink"><i class="fa fa-plus-square" aria-hidden="true"> Asignar caja a usuario</i></a>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <a href="espacios.php" class="orange-color" id="toolLink"><i class="fa fa-folder" aria-hidden="true"> Asignar espacio a usuario</i></a>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <a href="listadoUsuarios.php" class="orange-color" id="toolLink"><i class="fa fa-list-alt" aria-hidden="true"> Listado de usuarios</i></a>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <a href="listadoCajas.php" class="orange-color" id="toolLink"><i class="fa fa-archive" aria-hidden="true"> Listado de cajas</i></a>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <a href="listadoEspacios.php" class="orange-color" id="toolLink"> <i class="fa fa-building" aria-hidden="true"> Listado de espacios</i></a>
                            </td>
                        </tr>
                    </table>
            <!-- Si el rol = 0, significa que esta logueado como usuario, muestra este menu -->
                <?php } elseif ($rol == 0) { ?>
                    <table>
                        <tr>
                            <td>
                                <a href="modifyDates.php" class="orange-color" id="toolLink"><i class="fa fa-pencil-square-o"> Modificar datos</i></a>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                <a href="listadoCajas.php" class="orange-color" id="toolLink"><i class="fa fa-list-alt"> Listado de cajas</i></a>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <a href="listadoEspacios.php" class="orange-color" id="toolLink"><i class="fa fa-archive" aria-hidden="true"> Listado de espacios</i></a>
                            </td>
                        </tr>
                    </table>
                <?php } ?>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $(".jm-loadingpage").fadeOut("slow");
    });
</script>
<?php
footer();
?>