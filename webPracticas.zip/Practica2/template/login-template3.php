<div class="d-flex flex-column min-vh-100 justify-content-center align-items-center" id="template-bg-3">
	<?php
	if (!empty($_SESSION["msgRegistro"])) {
	?>
		<div class="alert alert-success"><?php echo $_SESSION["msgRegistro"]; ?></div>
	<?php
		$_SESSION['msgRegistro'] = null;
	}
	?>

	<img src="images/logo_Guardamelo.png" alt="Logo de guardamelo">



	<div class="card mb-5 p-5 bg-gradient text-white" id="orange-box">
		<div class="col-md-100">
			<div class="text-center">
				<h3>Inicio de sesión</h3>
			</div>
			<div class="mt-3">
				<form name="login" action="" method="post">
					<div class="input-group form-group mt-3">
						<input type="text" class="form-control text-center p-3" placeholder="E-mail" name="email">
					</div>
					<div class="input-group form-group mt-3">
						<input type="password" class="form-control text-center p-3" placeholder="Contraseña" name="password">
					</div>
					<div class="text-center">
						<input type="submit" value="Login" class="btn mt-3 w-100 p-2" name="login-btn" id="blue-box">
					</div>
				</form>
				<?php if (!empty($loginResult)) { ?>
					<br>
					<input type="button" value="<?php echo $loginResult; ?>" class="btn mt-3 w-100 p-1 bg-warning text-dark" disabled>

					<div class="bg-warning text-danger" <?php echo $loginResult; ?>></div>
				<?php } ?>
			</div>
			<div class="p-3">
				<div class="d-flex justify-content-center">
					<div><a class="blue-color" href="cambioPassword.php">¿Olvidó su contraseña?</div>
				</div>
				<div class="d-flex justify-content-center">
					<div><a class="blue-color" href="register.php">Registrarse</a></div>
				</div>

			</div>
		</div>
	</div>

</div>