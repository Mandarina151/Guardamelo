<?php
//Llamando a utiles que seran necesarios.
namespace Phppot;
use PHPMailer\PHPMailer\PHPMailer;

//Definiendo la clase Miembro, que sera la que utilicemos a la hora de llamar una funcion 
class Member
{

    private $ds;

    function __construct()
    {
        require_once __DIR__ . '/../lib/DataSource.php';
        $this->ds = new DataSource();
    }


    ///////////////////////////////////////////CONSULTAS A TABLA TBL_MEMBER/////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /////////////////////////////////////////CONSULTAS DE SELECT/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * The next fuction will get the assignated user to the inputed e-mail.
     * La siguiente función llevará al usuario asignado al correo electrónico ingresado.
     */

    public function getMember($email)
    {
        $query = 'SELECT * FROM tbl_member where email = ?';
        $paramType = 's';
        $paramValue = array(
            $email
        );
        $memberRecord = $this->ds->select($query, $paramType, $paramValue);
        return $memberRecord;
    }

    /**
     * The next fuction will get the assignated user to the inputed e-mail.
     * La siguiente función llevará al usuario asignado al correo electrónico ingresado.
     */
    /*

   public function getMemberByEailAndPassword($email)
   {
       $query = 'SELECT * FROM tbl_member where email = ?';
       $paramType = 's';
       $paramValue = array(
           $email
       );
       $memberRecord = $this->ds->select($query, $paramType, $paramValue);
       return $memberRecord;
   }
*/
    /**
     * La siguiente función devolverá todos los usuarios que no son administradores.
     */
    public function getAll()
    {
        $rol = 0;
        $query = 'SELECT * FROM tbl_member where rol = ?';
        $paramType = 's';
        $paramValue = array(
            $rol
        );
        $AllUsers = $this->ds->select($query, $paramType, $paramValue);
        return $AllUsers;
    }

    /**
     * The next function will return the user with the exact code activation.
     */
    public function getMemberByCode($code)
    {
        $query = 'SELECT * FROM tbl_member where activation = ?';
        $paramType = 's';
        $paramValue = array(
            $code
        );
        $memberRecord = $this->ds->select($query, $paramType, $paramValue);
        return $memberRecord;
    }
    /**
     * La siguiente función devolverá al usuario el código exacto de activación.
     */
    public function getMemberByCodeStatus($code)
    {
        $query = 'SELECT * FROM tbl_member where activation = ? AND status ="0"';
        $paramType = 's';
        $paramValue = array(
            $code
        );
        $memberRecord = $this->ds->select($query, $paramType, $paramValue);
        return $memberRecord;
    }

    ///////////////////////////////////////////CONSULTAS DELETE////////////////////////////////

    /**
     * La siguiente función eliminará el usuario seleccionado por id.
     */
    public function deleteUser($id)
    {
        $query = 'DELETE FROM tbl_member where id = ?';
        $paramType = 's';
        $paramValue = array(
            $id
        );
        // use exec() because no results are returned
        $this->ds->execute($query, $paramType, $paramValue);
    }

    ///////////////////////////////////////////CONSULTAS UPDATE////////////////////////////////

    /**
     * La siguiente función actualizará al usuario al estado 1 (correo electrónico confirmado).
     */
    public function confirmMember($code)
    {
        $query = "UPDATE `tbl_member` SET `status` = '1' WHERE `activation` = '" . $code . "';";
        // use exec() porque no se devuelven resultados
        return $this->ds->execute($query);
    }

    /**
     * 
     */
    public function updatePassword($email, $pass)
    {
        //Crypting the pass. Encriptando la contraseña
        $contraseñaCrypt = password_hash($pass, PASSWORD_DEFAULT);

        $query = "UPDATE `tbl_member` SET `password` = '" . $contraseñaCrypt . "' WHERE `email` = '" . $email . "';";
        // use exec() because no results are returned
        return $this->ds->execute($query);
    }

    ///////////////////////////////////////////CONSULTAS INSERT////////////////////////////////

    /**
     * The next function will add the inputed user to DB.
     */
    public function addMember($nombre, $apellidos, $email, $direccion, $contraseña, $telefono, $activation)
    {
        //Crypting the password
        $contraseñaCrypt = password_hash($contraseña, PASSWORD_DEFAULT);
        //setting up the query
        $query = "INSERT INTO `tbl_member` (`id`, `email`, `password`, `create_at`, `nombre`, `apellidos`, `telefono`, `direccion`, `rol`,`activation`,`status`) 
            VALUES (NULL, '" . $email . "', '" . $contraseñaCrypt . "', current_timestamp(), '" . $nombre . "', '" . $apellidos . "', '" . $telefono . "', '" . $direccion . "', '0','" . $activation . "' ,'0'); ";
        // use exec() because no results are returned
        $this->ds->execute($query);
    }



    ///////////////////////////////////////////CONSULTAS A TABLA almacenamiento/////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////CONSULTAS SELECT/////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * The next fuction will get the assignateds boxes to the inputed userId.
     * La siguiente función obtendrá las cajas asignados al Id de usuario introducido.
     */
    public function getBox($id)
    {
        $query = 'SELECT * FROM almacenamiento where userId = ?';
        $paramType = 's';
        $paramValue = array(
            $id
        );
        $boxRecord = $this->ds->select($query, $paramType, $paramValue);
        return $boxRecord;
    }

    /**
     * The next fuction will get the assignateds boxes to the inputed userId and code.
     */
    public function getBoxByIdAndCode($id, $code)
    {
        $int = intval($id);
        var_dump($code);
        $query = 'SELECT * FROM almacenamiento where userId = ? AND codigo_caja =  ? ';
        $paramType = 's';
        $paramValue = array(
            $int,
            $code
        );
        $boxRecord = $this->ds->select($query, $paramType, $paramValue);
        return $boxRecord;
    }

    /**
     * The next fuction will get alll the boxes.
     * La siguiente función obtiene la lista de todas las cajas de la base de datos
     */
    public function getAllBoxes()
    {
        $query = 'SELECT * FROM almacenamiento';
        $paramType = 's';
        $paramValue = array();
        $boxRecord = $this->ds->select($query, $paramType, $paramValue);
        return $boxRecord;
    }

    ///////////////////////////////////////////CONSULTAS DELETE/////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * The next function will delete a box by the iduser and code of box.
     */
    public function removeBox($idUser, $codigoCaja)
    {
        $int = intval($idUser);
        $query = "DELETE FROM `almacenamiento` WHERE `userId` = '" . $int . "' AND  `codigo_caja` = '" . $codigoCaja . "';";

        // use exec() because no results are returned
        $this->ds->execute($query);
    }

    ///////////////////////////////////////////CONSULTAS A TABLA espacios/////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////CONSULTAS SELECT/////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * The next fuction will get the assignateds boxes to the inputed userId.
     * La siguiente función obtendrá las cajas asignadas al Id de usuario introducido.
     */
    public function getEspacio($id)
    {
        $query = 'SELECT * FROM espacios where userId = ? AND pagoConfirmado=0';
        $paramType = 's';
        $paramValue = array(
            $id
        );
        $espacioRecord = $this->ds->select($query, $paramType, $paramValue);
        return $espacioRecord;
    }
                            
    /**
     * The next fuction will get the assignateds boxes to the inputed userId.
     * La siguiente función obtendrá las cajas asignadas al Id de usuario introducido.
     */
    public function getEspacioPagado($id)
    {
        $query = 'SELECT * FROM espacios where userId = ? AND pagoConfirmado=1';
        $paramType = 's';
        $paramValue = array(
            $id
        );
        $espacioRecord = $this->ds->select($query, $paramType, $paramValue);
        return $espacioRecord;
    }

    /**
     * The next fuction will get the assignateds boxes to the inputed userId.
     * La siguiente función obtendrá los cuadros asignados al ID de usuario introducido.
     */
    public function getAllEspaciosNoPagados()
    {
        $query = 'SELECT * FROM espacios where pagoConfirmado = 0';
        $paramType = 's';
        $paramValue = array();
        $espacioRecord = $this->ds->select($query, $paramType, $paramValue);
        return $espacioRecord;
    }

    /**
     * The next fuction will get the assignateds boxes to the inputed userId.
     * La siguiente función obtendrá los cuadros asignados al ID de usuario introducido.
     */
    public function getAllEspaciosPagados()
    {
        $query = 'SELECT * FROM espacios where pagoConfirmado = 1';
        $paramType = 's';
        $paramValue = array();
        $espacioRecord = $this->ds->select($query, $paramType, $paramValue);
        return $espacioRecord;
    }



    /**
     * The next fuction will get alll the boxes.
     * La siguiente función obtendra toda la lista de cajas que esta en la base de datos
     */
    public function getAllEspacios()
    {
        $query = 'SELECT * FROM espacios';
        $paramType = 's';
        $paramValue = array();
        $espaciosRecord = $this->ds->select($query, $paramType, $paramValue);
        return $espaciosRecord;
    }
    ///////////////////////////////////////////CONSULTAS INSERT/////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * The next function will add the inputed user to DB.
     */
    public function crearEspacio($idUser, $espacio, $precio)
    {
        $date = date("Y") . "-" . date("m") . "-" . date("d");
        //setting up the query
        $query = "INSERT INTO `espacios` (`id`, `userId`, `medida`, `precio`, `pagoConfirmado`, `fecha`) 
            VALUES (NULL, '" . $idUser . "', '" . $espacio . "', '" . $precio . "', '0' ,'" . $date . "');";
        // use exec() because no results are returned
        $this->ds->execute($query);
    }

    ///////////////////////////////////////////CONSULTAS UPDATE/////////////////////////////////////////////////////////////////////////////////////////////////////////////


    public function confirmarEspacioPagado($id)
    {
        $query = "UPDATE `espacios` SET `pagoConfirmado` = '1' WHERE `id` = '" . $id . "';";
        // use exec() because no results are returned
        return $this->ds->execute($query);
    }


    ///////////////////////////////////////////CONSULTAS DELETE/////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * The next function will delete the user selected by id.
     */
    public function borrarEspacio($id)
    {
        $query = 'DELETE FROM espacios where id = ?';
        $paramType = 's';
        $paramValue = array(
            $id
        );
        // use exec() because no results are returned
        $this->ds->execute($query, $paramType, $paramValue);
    }


    /**
     * The next function will be used when we need to convert a code into string.
     */
    public function convertString($code)
    {
        //Returning the function that convert the code into String.
        return $this->ds->stringConverter($code);
    }

    /**
     * The next function will be used when we need to count a row.
     */
    public function countRow($toCount)
    {
        //Returning the function that convert to count into a row.
        return $this->ds->countRows($toCount);
    }



    /**
     * The following function will initialize the session of the imputed user if exits.
     * Also will check if the user have boxes.
     * Otherwise will return a message for the user.
     */
    public function loginMember()
    {
        //Checking if the user exits.
        $memberRecord = $this->getMember($_POST["email"]);
        $loginPassword = 0;
        if (!empty($memberRecord)) {
            //Now we will check if the password its valid.
            if (!empty($_POST["password"])) {
                $password = $_POST["password"];
            }
            $hashedPassword = $memberRecord[0]["password"];
            $loginPassword = 0;

            if ($memberRecord[0]["status"] == 0) {
                $loginPassword = 2;
            } elseif (password_verify($password, $hashedPassword)) {
                $loginPassword = 1;
            }
        } else {
            $loginPassword = 0;
        }
        if ($loginPassword == 1) {
            //Setting up the $Session that we are going to need.
            session_start();
            $_SESSION["email"] = $memberRecord[0]["email"];
            $_SESSION["apellidos"] = $memberRecord[0]["apellidos"];
            $_SESSION["telefono"] = $memberRecord[0]["telefono"];
            $_SESSION["direccion"] = $memberRecord[0]["direccion"];
            $_SESSION["nombre"] = $memberRecord[0]["nombre"];
            $_SESSION["rol"] = $memberRecord[0]["rol"];
            $_SESSION["id"] = $memberRecord[0]["id"];

            //Now we will check if the users have boxes or not.
            $box = $this->getBox($memberRecord[0]["id"]);
            if (!empty($box)) {
                $_SESSION["caja"][] = $box;
            }

            session_write_close();
            $url = "loggedIn.php";
            header("Location: $url");
        } //if the user not exits 
        else if ($loginPassword == 0) {
            $loginStatus = "Email o contraseña no validos.";
            return $loginStatus;
        } else if ($loginPassword == 2) {
            $loginStatus = "Email no verificado.Revise su correo para verificar.";
            return $loginStatus;
        }
    }
    /**
     * The next function will add a user to DB, checking if the inputed e-mail exitst.
     * if the user exist will an email will be sended to the user inputed email.
     */
    public function registerMember($nombre, $apellidos, $email, $direccion, $contraseña, $telefono)
    {
        //Checking if the inputed e-mail exists
        $flag = true;
        $users = $this->getAll();
        for ($i = 0; $i < count($users); $i++) {
            if ($users[$i]["email"] == $email) {
                $flag = false;
            }
        }
        if ($flag) {
            //Sending confirmation email.
            $activation = md5($email . time()); // encrypted email+timestamp
            $subject = "Verificacion de correo";
            $body = '¡Hola! <br/> <br/> Porfavor verifique su correo para poder empezar a utilizar su cuenta en GUARDAMELO. <br/> <br/> <a href="' . $this->ds::main_url . 'activation.php?code=' . $activation . '">' . $this->ds::main_url . 'activation.php?code=' . $activation . '</a>
            <br/> <br/>
            <img src="https://www.guardamelo.com/wp-content/uploads/2021/09/LOGO_GUARDAMELO_CLAIM-3.png" alt="Logo guardamelo width="330" height="234""> 
            ';

            $sendedEmail = $this->sendEmail($email, $subject, $body);

            //if the email is sended.
            if ($sendedEmail == true) {
                //Calling a function to add the user
                $this->addMember($nombre, $apellidos, $email, $direccion, $contraseña, $telefono, $activation);
                $_SESSION["msgRegistro"] = "Correo añadido correctamente, revise su correo para confirmar.";
                $url = "index.php";
                header("Location: $url");
            } else {    //otherwise the user will be informed about the error.
                $_SESSION["msgRegistro"] = "Algo ha salido mal, vuelva a intentarlo más tarde.";
                $url = "index.php";
                header("Location: $url");
            }
        } else {
            //Returning a message error when e-mail already exists.
            $statusMsg = "El correo añadido ya existe.";
            return $statusMsg;
        }
    }

    /**
     *The next fuction will be called when the user admin is about to upload a box for a user. 
     */
    public function uploadFile($codeBox, $userId)
    {
        $statusMsg = '';
        // File upload path
        $targetDir = "images/userImage/";

        //Setting up the day to get a unic name.
        date_default_timezone_set('UTC');
        $fileName = basename($_FILES["file"]["name"]);
        $nombreImagen = date('Y-m-d-h-i-s') . "_" . $fileName;


        //Setting up the path where the file will be uploaded.
        $targetFilePath = $targetDir . $nombreImagen;
        $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

        if (isset($_POST["upload-btn"]) && !empty($_FILES["file"]["name"])) {
            // Allow certain file formats
            $allowTypes = array('jpg', 'png', 'jpeg', 'gif', 'pdf');
            if (in_array($fileType, $allowTypes)) {
                // Upload file to server
                if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)) {
                    // Insert image file name into database

                    $query = "INSERT INTO `almacenamiento` (`id`, `codigo_caja`, `Foto`, `userId`) 
                    VALUES (NULL, '" . $codeBox . "', '" . $nombreImagen . "', '" . $userId . "'); ";
                    $insert = $this->ds->insert($query);
                    if (!empty($insert)) {
                        $statusMsg = "La caja fue correctamente creada.";
                    } else {
                        $statusMsg = "Fallo al subir el archivo, inténtelo de nuevo.";
                    }
                } else {
                    $statusMsg = "Hubo un error subiendo el archivo";
                }
            } else {
                $statusMsg = 'Solo ficheros con formato imagen (jpg,png,gif,etc.)';
            }
        } else {
            $statusMsg = 'Seleccione un fichero para subir.';
        }

        // Display status message
        return $statusMsg;
    }

    /**
     * the next function will make sure that the array of users is not empty.
     */
    public function getAllUsers()
    {
        $users = $this->getAll();
        if (!empty($users)) {
            $flag = true;
        } else {
            $flag = false;
        }

        if ($flag) {
            return $users;
        } else {
        }
    }
    /**
     * The following function will initialize the session of the imputed user if exits.
     * Also will check if the user have boxes.
     * Otherwise will return a message for the user.
     */
    public function deleteMember()
    {
        //Checking if the user exits.
        $memberRecord = $this->getMember($_POST["email"]);
        $flag = true;

        if (!empty($memberRecord)) {
            //Now we will delete the selected user
            $this->deleteUser($memberRecord[0]["id"]);
        } else {
            $flag = false;
        }
        if ($flag == true) {
            //Reloading the page.
            $url = "listadoUsuarios.php";
            header("Location: $url");
        } //if the user not exits 
        else {
            $statusMsg = "Usuario no existe";
            return $statusMsg;
        }
    }


    /**
     * The following function will delete a box.
     * will delete the box and then will reload the page
     * Otherwise will return a message for the user.
     */
    public function deleteBox()
    {
        // we will delete the selected box
        $this->removeBox($_POST["userId"], $_POST["codigo_caja"]);

        //Reloading the page.
        $url = "listadoCajas.php";
        header("Location: $url");
    }

    public function restorePassword($email)
    {
        $alert = "danger";

        $memberRecord = $this->getMember($email);
        $loginPassword = 0;
        if (!empty($memberRecord)) {
            //Now we will check if the password its valid.
            $checkemail = $memberRecord[0]["email"];
            $loginPassword = 0;
            if (strcmp($checkemail, $email) == 0) {
                $loginPassword = 1;
            }

            if ($loginPassword == 0) {
                //Si la contraseña no coincide
                $statusMsg = "Usuario no encontrado";
                $data = array(
                    $alert,
                    $statusMsg
                );
                return $data;
            } else if ($loginPassword == 1) {
                //Aqui enviaremos email
                $criptedEmail = md5($email); // encrypted email+timestamp
                $subject = "Cambio de contraseña en GUARDAMELO";
                $body = '¡Hola! <br/> <br/> Clicke en el siguiente enlace para restablecer su contraseña. <br/> <br/> <a href="' . $this->ds::main_url . 'confirmacionContraseña.php?email=' . $criptedEmail . '">Clicke aquí</a>
                <br/> <br/>
                <img src="https://www.guardamelo.com/wp-content/uploads/2021/09/LOGO_GUARDAMELO_CLAIM-3.png" alt="Logo guardamelo width="330" height="234""> 
                ';

                $sendedEmail = $this->sendEmail($email, $subject, $body);


                if ($sendedEmail == true) {
                    //Calling a function to add the user
                    $alert = "success";
                    $statusMsg = "Revise su correo para modificar su contraseña.";
                    $data = array(
                        $alert,
                        $statusMsg
                    );
                    return $data;
                } else {    //otherwise the user will be informed about the error.
                    $statusMsg = "Error al enviar el correo.";
                    $data = array(
                        $alert,
                        $statusMsg
                    );
                    return $data;
                }
            }
        } else {
            //Si el email no se encuentra.
            $statusMsg = "Usuario no encontrado";
            $data = array(
                $alert,
                $statusMsg
            );
            return $data;
        }
    }

    /**
     * The next function will crypt the inputed password and then the user pass will be reasigned.
     */
    public function alternarEspacio($id, $sqlOperation)
    {
        //Obteniendo todos los espacios para poder comprobar que el espacio confirmado exista.
        $espacioRecord = $this->getAllEspacios();
        $flag = false;

        if (!empty($espacioRecord)) {
            for ($i = 0; $i < count($espacioRecord); $i++) {
                if ($espacioRecord[$i]["id"] == $id) {
                    $flag = true;
                    break;
                }
            }
            if ($flag == true) {
                if ($sqlOperation == 1) {
                    $this->confirmarEspacioPagado($id);
                    $_SESSION["statusEspacio"] = "Espacio confirmado correctamente";
                } else if ($sqlOperation == 2) {
                    $this->borrarEspacio($id);
                    $_SESSION["statusEspacio"] = "Espacio confirmado correctamente";
                }
                $url = "listadoEspacios.php";
                header("Location: $url");
            } else {
                $_SESSION["statusEspacio"] = "Espacio no encontrado en la base de datos.";
                $url = "listadoEspacios.php";
                header("Location: $url");
            }
        } else {
            $_SESSION["statusEspacio"] = "Error en la conexion sql.";
            $url = "listadoEspacios.php";
            header("Location: $url");
        }
    }


    /**
     * The next function will crypt the inputed password and then the user pass will be reasigned.
     */
    public function updatePass($email, $password)
    {
        //Checking if the user exits.
        $memberRecord = $this->getMember($email);

        if (!empty($memberRecord)) {
            //Now we will check if the password its valid.
            $this->updatePassword($email, $password);
            $_SESSION["msgRegistro"] = "Contraseña cambiada correctamente";
            $url = "index.php";
            header("Location: $url");
        }
    }


    /**
     * The following function will send an email to the inputed user email($to).
     * Also will set up the subject($subject) and the body($body) of the email.
     * If the user cannot be sended will return false, otherwise true.
     */
    public function sendEmail($to, $subject, $body)
    {
        require 'vendor/autoload.php';
        $from = 'no-reply@guardamelo.com';
        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->SMTPDebug = 0;
        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        $mail->Host = 'smtp.dondominio.com';
        $mail->Port = 587;
        $mail->SMTPAuth = true;
        $mail->Username = 'no-reply@guardamelo.com';
        $mail->Password = 'X{[D/?7xs}7[';
        $mail->setFrom($from, 'No-reply');
        $mail->addReplyTo($from, 'No-reply');
        $mail->addAddress($to, 'Nuevo usuario');
        $mail->Subject = $subject;
        $mail->msgHTML($body);
        if (!$mail->send()) {
            return false;
        } else {
            return true;
        }
    }
}
