<?php
//Llama al archivo utilities.php
// error_reporting(0); //Desactiva las notificaciones de PHP
require_once "utilities.php";

use Phppot\Member;

menu("Confirmar contraseña", "register.css"); //Llama a la funcion menu que esta en el archivo utilities.php
menuNoUser(); //Menu no usuario


$password = $password2 = $errorPassword2 = $errorPassword = $emailToUpdate = "";
$flag = false;

//Verificamos que el input del email no este vacio
if (!empty($_GET['email']) && isset($_GET['email'])) {
    require_once __DIR__ . '/lib/Member.php';
    $member = new Member();
    $email = $_GET['email'];
    $users = $member->getAll();
    $msg = "";

    if (!empty($users)) {
        $check = 0;
        for ($i = 0; $i < count($users); $i++) {
            $cryptEmail = md5($users[$i]["email"]);

            if ($email == $cryptEmail) {
                $emailToUpdate = $users[$i]["email"];
                $check = 0;
                break;
            } else {
                $check = 1;
            }
        }
        if ($check == 0) {
            $msg = "Email encontrado";
        } elseif ($check == 1) {
            session_unset();
            $url = "./index.php";
            header("Location: $url");
        }
    } else {
        $msg = "Algo ha ido mal. Vuelva a intentarlo más tarde.";
    }
} else {
    session_unset();
    $url = "./index.php";
    header("Location: $url");
}
if (isset($_POST["updatePass"])) {
    $password = testInput($_POST["password"]);
    $password2 = testInput($_POST["password2"]);
    /**********************************VALIDACIÓN CONTRASEÑA********************************** */
    if (empty($password)) {
        $flag = true;
        $errorPassword = "La contraseña no debe estar vacía";
    } else {
    }
    /**********************************VALIDACIÓN DE REPETIR CONTRASEÑA********************************** */
    if(empty($password2)){
        $flag = true;
        $errorPassword2 = "La confirmación de contraseña no debe estar vacía";
    }   elseif ($password != $password2) {
        $flag = true;
        $errorPassword2 = "Las contraseñas deben ser iguales";
    }
    if ($flag != false) { //($flag == true)
        //Parte del error
    } else {
        //En caso de que no haya error ($flag == false)
        require_once __DIR__ . '/lib/Member.php';
        $member = new Member();
        $member->updatePass($emailToUpdate, $password);
    }
}
?>
<!-- ****************************FORMULARIO DE REGISTRO******************************************** -->
<div class="d-flex flex-column min-vh-100 justify-content-center align-items-center" id="register-box">
    <div class="d-flex flex-column min-vh-100 justify-content-center align-items-center" id="paddingMainDiv">
        <?php
        if ($check > 0) { ?>
            <div class="col-md-12 text-center mt-5 blue-color">
                <?php echo $msg; ?>
            </div>
        <?php  } else { ?>
            <img src="images/logo_Guardamelo.png" alt="Logo de guardamelo">
            <div class="row">
                <div class="container col-11 col-sm-8 col-md-10 col-lg-10 formulario">
                    <form class="form-horizontal" method="post" action="<?php echo  ($_SERVER["PHP_SELF"]. '?'.http_build_query($_GET)); ?>">
                        <h1 class="text-center m-5">Cambio de contraseña</h1>
                        <p class="text-white ml-4">* Campos obligatorios</p>
                        <!-- password -->
                        <div class="container">
                            <div class="campo">
                                <label for="password"></label>
                                <input type="password" id="password" class="form-control mb-2" name="password" placeholder="Contraseña *" value="<?php echo $password ?>">
                                <button type="button" class="btn btn-primary buttonPassword">Mostrar</button>
                                <span class="text-danger"> <?php echo $errorPassword ?></span>
                            </div>
                        </div>
                        <!-- repetir password -->
                        <div class="container mb-3">
                            <div class="campo2">
                                <label for="password2"></label>
                                <input type="password" id="password2" class="form-control mb-2" name="password2" placeholder="Repite tu contraseña  *" value="<?php echo $password2 ?>">
                                <button type="button" class="btn btn-primary buttonPassword">Mostrar</button>
                                <span class="text-danger"> <?php echo $errorPassword2 ?></span>
                            </div>
                        </div>
                        <input type="text" name="email" value="<?php print_r($emailToUpdate); ?>" style="display: none;">
                        <!-- Botón de registrar -->
                        <div class="container mb-5 mt-3 registrar">
                            <input type="submit" name="updatePass" value="Confirmar" class="btn btn-lg btn-block">
                        </div>

                    </form>
                    <!--fin del formulario de registro -->
                </div>
            </div>
        <?php } ?>
    </div>
</div>
<script>
    $(document).ready(function() {
        $(".jm-loadingpage").fadeOut("slow");
    });
    //Script para mostrar / ocultar los botones para ver la contraseña introducida por el usuario
    document.querySelector('.campo button').addEventListener('click', e => {
        const passwordInput = document.querySelector('#password');
        if (e.target.classList.contains('show')) {
            e.target.classList.remove('show');
            e.target.textContent = 'Ocultar';
            passwordInput.type = 'text';
        } else {
            e.target.classList.add('show');
            e.target.textContent = 'Mostrar';
            passwordInput.type = 'password';
        }
    });
    //Script para mostrar / ocultar los botones para ver la contraseña introducida por el usuario
    document.querySelector('.campo2 button').addEventListener('click', e => {
        const passwordInput2 = document.querySelector('#password2');
        if (e.target.classList.contains('show')) {
            e.target.classList.remove('show');
            e.target.textContent = 'Ocultar';
            passwordInput2.type = 'text';
        } else {
            e.target.classList.add('show');
            e.target.textContent = 'Mostrar';
            passwordInput2.type = 'password';
        }
    });
</script>
</body>
<?php
footer();
?>

</html>