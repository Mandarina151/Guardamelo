<?php
//logut.php will destroy the session and then will load the index.php file once is destroyed.
//logout.php destruirá la sesión y luego cargará el archivo index.php una vez destruido.
require_once "utilities.php"; //llama al archivo php
menuUser(); //llama al menu usuario
if (!empty($_SESSION["email"])) {
} else {
    $url = "./index.php";
    header("Location: $url");
}
if (isset($_SESSION["email"])) {
	session_destroy();//Destruye la sesión
	header("Location: index.php"); //nos redirige al file index.php
}
?>
<script>
	//JS para recargar actualizar la pagina
	$(document).ready(function() {
		$(".jm-loadingpage").fadeOut("slow");
	});
</script>
</body>

</html>